import os
import zipfile
import shutil

def create_zips():
    base_dir = os.path.abspath(".")
    public_dir = os.path.join(base_dir, "public")
    os.makedirs(public_dir, exist_ok=True)
    
    artifact_dir = "/.aistudio/artifacts/brain/4570b93b-e50f-4812-8cc1-04dd25965c8b"
    os.makedirs(artifact_dir, exist_ok=True)

    # 1. Create Android Studio dedicated zip (ready to open in Android Studio)
    android_dir = os.path.join(base_dir, "android-studio-project")
    android_zip_public = os.path.join(public_dir, "selavu-android-studio-project.zip")
    android_zip_root = os.path.join(base_dir, "selavu-android-studio-project.zip")
    android_zip_artifact = os.path.join(artifact_dir, "selavu-android-studio-project.zip")

    if os.path.exists(android_dir):
        with zipfile.ZipFile(android_zip_public, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(android_dir):
                for file in files:
                    if file.endswith(".zip"):
                        continue
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, android_dir)
                    zipf.write(full_path, arcname=rel_path)
        shutil.copy2(android_zip_public, android_zip_root)
        shutil.copy2(android_zip_public, android_zip_artifact)
        print(f"Created {android_zip_public} ({os.path.getsize(android_zip_public)} bytes)")

    # 2. Create Complete Full-Source Zip
    full_zip_public = os.path.join(public_dir, "selavu-complete-project.zip")
    full_zip_root = os.path.join(base_dir, "selavu-complete-project.zip")
    full_zip_artifact = os.path.join(artifact_dir, "selavu-complete-project.zip")

    exclude_dirs = {"node_modules", ".git", ".playwright-cli", ".cache", "__pycache__"}
    exclude_files = {
        "selavu-complete-project.zip",
        "selavu-android-studio-project.zip",
        "package-lock.json",
    }

    count = 0
    with zipfile.ZipFile(full_zip_public, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(base_dir):
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith(".playwright")]
            for file in files:
                if file in exclude_files or file.endswith(".zip"):
                    continue
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, base_dir)
                zipf.write(full_path, arcname=rel_path)
                count += 1

    shutil.copy2(full_zip_public, full_zip_root)
    shutil.copy2(full_zip_public, full_zip_artifact)
    print(f"Created {full_zip_public} with {count} files ({os.path.getsize(full_zip_public)} bytes)")

if __name__ == "__main__":
    create_zips()
