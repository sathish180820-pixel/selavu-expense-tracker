# Selavu (செலவு) — Complete Android Personal Expense Tracker

A complete, responsive, offline-first personal expense tracker with a premium neon-dark UI, animated Indian rupee cash-flow splash screen, 24-page inventory, and button-by-button working actions.

**Developed by மூ சதீஷ்**

---

## 🚀 Features

- **24 Verified Pages**:
  - **Startup**: SplashPage (Cash Flow Animation), OnboardingWelcomePage, ProfileSetupPage, SavingsGoalPage
  - **Dashboard**: HomePage
  - **Expenses**: AddExpensePage, ExpenseSavedPage, HistoryPage, ExpenseDetailsPage, EditExpensePage
  - **Budgets**: BudgetsPage, AddBudgetPage, BudgetDetailsPage, EditBudgetPage
  - **Analytics**: AnalyticsPage, CategoryAnalyticsPage, MonthlyComparisonPage
  - **Profile & Settings**: ProfilePage, EditProfilePage, SettingsPage, CurrencySettingsPage, BackupRestorePage, ExportDataPage, AboutPage
- **Dynamic Allowance Calculation**:
  - `Monthly Allowance = Salary − Savings Goal`
  - `Remaining Allowance = Salary − Savings Goal − Current Month Expenses`
- **Integer Paise Precision**: Avoids floating-point currency calculation errors.
- **Offline Persistence**: Entire dataset stored securely in `localStorage` with JSON export/import and CSV download.
- **Indian Rupee Visuals**: Rupee note animation (`₹500`, `₹200`, `₹100`, `₹2000`), Indian locale numbering (`₹1,50,000`).

---

## 🛠️ How to Run Locally

### Prerequisites
- Node.js (version 18 or higher)
- npm or pnpm or yarn

### Installation
```bash
# 1. Install dependencies
npm install

# 2. Run the development server
npm run dev
```

Visit `http://localhost:3000` in your browser.

### Run Unit Tests
```bash
npx --yes tsx --test src/utils/finance.test.ts
```

### Build for Production
```bash
npm run build
```

---

## 📁 Project Structure

```
├── public/                 # Static assets & downloadable zip
├── src/
│   ├── components/         # Reusable UI components & DeveloperFooter
│   │   ├── AppHeader.tsx
│   │   ├── BottomNavigation.tsx
│   │   ├── DeveloperFooter.tsx
│   │   └── UIComponents.tsx
│   ├── context/            # AppContext with persistent storage & navigation
│   │   └── AppContext.tsx
│   ├── pages/              # All 24 pages
│   │   ├── SplashPage.tsx
│   │   ├── HomePage.tsx
│   │   ├── AddExpensePage.tsx
│   │   └── ...
│   ├── types/              # TypeScript models & enums
│   │   └── index.ts
│   ├── utils/              # Pure financial calculations & unit tests
│   │   ├── finance.ts
│   │   └── finance.test.ts
│   ├── App.tsx             # Master router & Android device shell
│   ├── index.css           # Tailwind CSS theme with neon glows
│   └── main.tsx            # Entry point
├── index.html              # HTML entry with Tamil & Grotesk typography
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---
Developed by **மூ சதீஷ்**
