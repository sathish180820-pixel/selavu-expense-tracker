export type ExpenseCategory = 
  | 'Food & Dining'
  | 'Transport'
  | 'Shopping'
  | 'Bills & Utilities'
  | 'Entertainment'
  | 'Health'
  | 'Groceries'
  | 'Education'
  | 'Travel'
  | 'Others';

export type PaymentMethod = 
  | 'UPI'
  | 'Cash'
  | 'Credit Card'
  | 'Debit Card'
  | 'Net Banking';

export interface UserProfile {
  id: string;
  name: string;
  email?: string;
  monthlySalaryPaise: number;
  savingsGoalPaise: number;
  currencySymbol: string;
  currencyCode: string;
  onboardingComplete: boolean;
  avatarSeed?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Expense {
  id: string;
  amountPaise: number;
  category: ExpenseCategory;
  merchant: string;
  paymentMethod: PaymentMethod;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Budget {
  id: string;
  category: ExpenseCategory | 'Overall';
  monthlyLimitPaise: number;
  period: 'monthly' | 'weekly';
  createdAt: string;
  updatedAt: string;
}

export interface AppSettings {
  currencySymbol: string;
  currencyCode: string;
  notificationsEnabled: boolean;
  biometricLock: boolean;
  soundEffects: boolean;
  theme: 'neon-dark';
  language: 'ta-en' | 'en' | 'ta';
  lastBackupDate?: string;
}

export type PageName =
  | 'SplashPage'
  | 'OnboardingWelcomePage'
  | 'ProfileSetupPage'
  | 'SavingsGoalPage'
  | 'HomePage'
  | 'AddExpensePage'
  | 'ExpenseSavedPage'
  | 'HistoryPage'
  | 'ExpenseDetailsPage'
  | 'EditExpensePage'
  | 'BudgetsPage'
  | 'AddBudgetPage'
  | 'BudgetDetailsPage'
  | 'EditBudgetPage'
  | 'AnalyticsPage'
  | 'CategoryAnalyticsPage'
  | 'MonthlyComparisonPage'
  | 'ProfilePage'
  | 'EditProfilePage'
  | 'SettingsPage'
  | 'CurrencySettingsPage'
  | 'BackupRestorePage'
  | 'ExportDataPage'
  | 'AboutPage';

export interface NavigationState {
  currentPage: PageName;
  previousPage?: PageName;
  params?: {
    expenseId?: string;
    budgetId?: string;
    category?: ExpenseCategory;
    period?: string;
    savedExpenseId?: string;
    fromPage?: PageName;
  };
}
