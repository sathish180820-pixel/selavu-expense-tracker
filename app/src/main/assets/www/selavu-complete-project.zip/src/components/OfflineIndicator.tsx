import React from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { WifiOff, Database } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-16 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 rounded-xl bg-[#1A1608] border border-[#FF5F1F]/50 px-3.5 py-2 text-xs font-medium text-[#FF8A00] shadow-[0_0_20px_rgba(255,95,31,0.3)] animate-bounce"
    >
      <WifiOff className="w-4 h-4 text-[#FF5F1F] shrink-0" />
      <span>Offline Mode — All transactions saved to local memory.</span>
    </div>
  );
};
