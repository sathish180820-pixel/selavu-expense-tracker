import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Smartphone, X, CheckCircle2 } from 'lucide-react';

export const PWAInstallButton: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [showAndroidGuide, setShowAndroidGuide] = useState(false);

  // If already running in standalone PWA mode
  if (isInstalled) {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs text-[#B6FF00] font-medium bg-[#B6FF00]/10 px-2.5 py-1 rounded-full border border-[#B6FF00]/30">
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span>Installed App</span>
      </span>
    );
  }

  return (
    <>
      <button
        onClick={async () => {
          if (isInstallable) {
            await install();
          } else if (isIOS) {
            setShowIOSGuide(true);
          } else {
            setShowAndroidGuide(true);
          }
        }}
        className={`inline-flex items-center gap-1.5 py-1.5 px-3 rounded-xl bg-gradient-to-r from-[#B6FF00]/20 to-[#00F5FF]/20 border border-[#B6FF00]/40 text-[#B6FF00] hover:bg-[#B6FF00]/30 font-semibold text-xs cursor-pointer transition-all shadow-[0_0_10px_rgba(182,255,0,0.15)] ${className}`}
        title="Install Selavu as an Offline Android / Desktop App"
      >
        <Smartphone className="w-3.5 h-3.5" />
        <span>Install App</span>
      </button>

      {/* Android / Desktop Instruction Modal */}
      {showAndroidGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#121216] border border-[#27272A] p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#27272A]">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-[#B6FF00]" />
                <h3 className="text-sm font-bold text-white">Install Selavu on Android</h3>
              </div>
              <button
                onClick={() => setShowAndroidGuide(false)}
                className="w-7 h-7 rounded-lg bg-[#1A1A22] text-[#888888] hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-[#CCC] leading-relaxed">
              <p>
                Selavu is a <strong>100% offline Progressive Web App</strong> that runs like a native APK without Google Play:
              </p>
              <div className="p-3 rounded-xl bg-[#0B0B0F] border border-[#27272A] space-y-2">
                <p>1. Open Chrome on your Android phone.</p>
                <p>2. Tap the <strong>⋮ (three dots menu)</strong> in Chrome.</p>
                <p>3. Tap <strong>Install app</strong> or <strong>Add to Home screen</strong>.</p>
                <p>4. Selavu will install directly onto your home screen and open offline full-screen!</p>
              </div>
            </div>

            <button
              onClick={() => setShowAndroidGuide(false)}
              className="w-full py-2.5 rounded-xl bg-[#B6FF00] text-black font-semibold text-xs hover:bg-[#c4ff2e] cursor-pointer"
            >
              Got it!
            </button>
          </div>
        </div>
      )}

      {/* iOS Safari Guide Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-2xl bg-[#121216] border border-[#27272A] p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#27272A]">
              <h3 className="text-sm font-bold text-white">Install on iPhone / iPad</h3>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="w-7 h-7 rounded-lg bg-[#1A1A22] text-[#888888] hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-[#CCC] leading-relaxed">
              1. Tap the <strong>Share</strong> button at the bottom of Safari.<br />
              2. Scroll down and tap <strong>Add to Home Screen</strong>.<br />
              3. Tap <strong>Add</strong> in the top right.
            </p>
            <button
              onClick={() => setShowIOSGuide(false)}
              className="w-full py-2.5 rounded-xl bg-[#00F5FF] text-black font-semibold text-xs hover:bg-[#3bf7ff] cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
