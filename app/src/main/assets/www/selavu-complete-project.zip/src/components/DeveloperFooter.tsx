import React from 'react';

interface DeveloperFooterProps {
  className?: string;
}

export const DeveloperFooter: React.FC<DeveloperFooterProps> = ({ className = '' }) => {
  return (
    <footer
      className={`w-full py-4 px-3 text-center select-none ${className}`}
      data-testid="developer-footer"
    >
      <p className="text-[#888888] text-xs font-normal font-tamil tracking-wide">
        Developed by <span className="font-semibold text-[#A1A1AA]">மூ சதீஷ்</span>
      </p>
    </footer>
  );
};
