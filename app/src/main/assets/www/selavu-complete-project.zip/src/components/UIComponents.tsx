import React from 'react';
import {
  Utensils,
  Car,
  ShoppingBag,
  Receipt,
  Film,
  HeartPulse,
  ShoppingCart,
  GraduationCap,
  Plane,
  MoreHorizontal,
  ChevronRight,
  AlertTriangle,
  CreditCard,
  Smartphone,
  Banknote,
  Building2,
  Calendar,
  Clock,
} from 'lucide-react';
import { Expense, ExpenseCategory, PaymentMethod, Budget } from '../types';
import { formatPaise, paiseToRupees } from '../utils/finance';

// Category color & icon mapping
export const CATEGORY_CONFIG: Record<
  ExpenseCategory,
  { icon: React.ComponentType<{ className?: string }>; color: string; bg: string }
> = {
  'Food & Dining': { icon: Utensils, color: '#FF5F1F', bg: 'rgba(255, 95, 31, 0.15)' },
  Transport: { icon: Car, color: '#00F5FF', bg: 'rgba(0, 245, 255, 0.15)' },
  Shopping: { icon: ShoppingBag, color: '#FF2D78', bg: 'rgba(255, 45, 120, 0.15)' },
  'Bills & Utilities': { icon: Receipt, color: '#BF00FF', bg: 'rgba(191, 0, 255, 0.15)' },
  Entertainment: { icon: Film, color: '#B6FF00', bg: 'rgba(182, 255, 0, 0.15)' },
  Health: { icon: HeartPulse, color: '#39FF14', bg: 'rgba(57, 255, 20, 0.15)' },
  Groceries: { icon: ShoppingCart, color: '#FFD700', bg: 'rgba(255, 215, 0, 0.15)' },
  Education: { icon: GraduationCap, color: '#00D2FF', bg: 'rgba(0, 210, 255, 0.15)' },
  Travel: { icon: Plane, color: '#FF8A00', bg: 'rgba(255, 138, 0, 0.15)' },
  Others: { icon: MoreHorizontal, color: '#A1A1AA', bg: 'rgba(161, 161, 170, 0.15)' },
};

export const PAYMENT_METHOD_ICONS: Record<PaymentMethod, React.ComponentType<{ className?: string }>> = {
  UPI: Smartphone,
  Cash: Banknote,
  'Credit Card': CreditCard,
  'Debit Card': CreditCard,
  'Net Banking': Building2,
};

// --- Neon Primary Button ---
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  icon?: React.ReactNode;
  fullWidth?: boolean;
  variant?: 'lime' | 'cyan' | 'pink' | 'danger';
}

export const NeonPrimaryButton: React.FC<ButtonProps> = ({
  children,
  icon,
  fullWidth = true,
  variant = 'lime',
  className = '',
  disabled,
  ...props
}) => {
  const variantStyles = {
    lime: 'bg-[#B6FF00] text-black hover:bg-[#c4ff2e] shadow-[0_0_15px_rgba(182,255,0,0.3)] hover:shadow-[0_0_25px_rgba(182,255,0,0.5)]',
    cyan: 'bg-[#00F5FF] text-black hover:bg-[#3bf7ff] shadow-[0_0_15px_rgba(0,245,255,0.3)] hover:shadow-[0_0_25px_rgba(0,245,255,0.5)]',
    pink: 'bg-[#FF2D78] text-white hover:bg-[#ff4d8d] shadow-[0_0_15px_rgba(255,45,120,0.3)] hover:shadow-[0_0_25px_rgba(255,45,120,0.5)]',
    danger: 'bg-red-600 text-white hover:bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.3)]',
  };

  return (
    <button
      {...props}
      disabled={disabled}
      className={`relative inline-flex items-center justify-center gap-2 font-semibold text-sm sm:text-base py-3.5 px-6 rounded-xl transition-all duration-200 active:scale-[0.98] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none ${
        variantStyles[variant]
      } ${fullWidth ? 'w-full' : ''} ${className}`}
    >
      {icon}
      <span>{children}</span>
    </button>
  );
};

// --- Neon Secondary Button ---
export const NeonSecondaryButton: React.FC<ButtonProps> = ({
  children,
  icon,
  fullWidth = true,
  className = '',
  disabled,
  ...props
}) => {
  return (
    <button
      {...props}
      disabled={disabled}
      className={`relative inline-flex items-center justify-center gap-2 font-medium text-sm sm:text-base py-3.5 px-6 rounded-xl bg-[#121216] text-white border border-[#27272A] hover:border-[#B6FF00]/50 hover:bg-[#1A1A22] transition-all duration-200 active:scale-[0.98] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
        fullWidth ? 'w-full' : ''
      } ${className}`}
    >
      {icon}
      <span>{children}</span>
    </button>
  );
};

// --- Financial Summary Card ---
interface FinancialSummaryCardProps {
  salaryPaise: number;
  savingsGoalPaise: number;
  monthlyExpensesPaise: number;
  currencySymbol?: string;
  onViewAnalytics?: () => void;
  onManageBudgets?: () => void;
}

export const FinancialSummaryCard: React.FC<FinancialSummaryCardProps> = ({
  salaryPaise,
  savingsGoalPaise,
  monthlyExpensesPaise,
  currencySymbol = '₹',
  onViewAnalytics,
  onManageBudgets,
}) => {
  const monthlyAllowance = Math.max(0, salaryPaise - savingsGoalPaise);
  const remainingAllowance = salaryPaise - savingsGoalPaise - monthlyExpensesPaise;
  const isNegative = remainingAllowance < 0;
  const spentPercent = monthlyAllowance > 0 ? Math.min(100, Math.round((monthlyExpensesPaise / monthlyAllowance) * 100)) : 0;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-5 shadow-xl">
      {/* Background glow accent */}
      <div className="absolute -top-12 -right-12 w-36 h-36 bg-[#B6FF00]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-12 -left-12 w-36 h-36 bg-[#00F5FF]/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header */}
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs uppercase tracking-wider text-[#A1A1AA] font-medium">
          Remaining Allowance
        </span>
        <span
          className={`text-xs px-2.5 py-0.5 rounded-full font-semibold ${
            isNegative
              ? 'bg-[#FF2D78]/20 text-[#FF2D78] border border-[#FF2D78]/30'
              : 'bg-[#B6FF00]/15 text-[#B6FF00] border border-[#B6FF00]/30'
          }`}
        >
          {isNegative ? 'Budget Overrun' : `${100 - spentPercent}% Left`}
        </span>
      </div>

      {/* Main Remaining Amount */}
      <div className="mb-4">
        <h2
          className={`text-3xl sm:text-4xl font-bold font-amount tracking-tight ${
            isNegative ? 'text-[#FF2D78]' : 'text-white'
          }`}
        >
          {formatPaise(remainingAllowance, currencySymbol)}
        </h2>
        <p className="text-xs text-[#888888] mt-1">
          Allowance: {formatPaise(monthlyAllowance, currencySymbol)} (Salary − Savings Goal)
        </p>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-[#050505] rounded-full h-2 mb-4 overflow-hidden border border-[#27272A]">
        <div
          className={`h-full rounded-full transition-all duration-500 ${
            spentPercent > 90
              ? 'bg-[#FF2D78]'
              : spentPercent > 70
              ? 'bg-[#FF5F1F]'
              : 'bg-[#B6FF00]'
          }`}
          style={{ width: `${Math.min(100, spentPercent)}%` }}
        />
      </div>

      {/* Sub-grid of metrics */}
      <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#27272A]/70 text-center">
        <div>
          <span className="text-[10px] text-[#888888] uppercase block">Salary</span>
          <span className="text-xs sm:text-sm font-semibold font-amount text-white">
            {formatPaise(salaryPaise, currencySymbol)}
          </span>
        </div>
        <div>
          <span className="text-[10px] text-[#888888] uppercase block">Savings Goal</span>
          <span className="text-xs sm:text-sm font-semibold font-amount text-[#00F5FF]">
            {formatPaise(savingsGoalPaise, currencySymbol)}
          </span>
        </div>
        <div>
          <span className="text-[10px] text-[#888888] uppercase block">Spent</span>
          <span className="text-xs sm:text-sm font-semibold font-amount text-[#FF5F1F]">
            {formatPaise(monthlyExpensesPaise, currencySymbol)}
          </span>
        </div>
      </div>

      {/* Quick shortcuts if provided */}
      {(onViewAnalytics || onManageBudgets) && (
        <div className="flex items-center gap-2 mt-4 pt-3 border-t border-[#27272A]">
          {onViewAnalytics && (
            <button
              onClick={onViewAnalytics}
              className="flex-1 py-1.5 px-3 rounded-lg bg-[#0B0B0F] hover:bg-[#1A1A22] text-[11px] text-[#A1A1AA] hover:text-[#00F5FF] border border-[#27272A] transition-colors cursor-pointer text-center"
            >
              View Analytics →
            </button>
          )}
          {onManageBudgets && (
            <button
              onClick={onManageBudgets}
              className="flex-1 py-1.5 px-3 rounded-lg bg-[#0B0B0F] hover:bg-[#1A1A22] text-[11px] text-[#A1A1AA] hover:text-[#B6FF00] border border-[#27272A] transition-colors cursor-pointer text-center"
            >
              Manage Budgets →
            </button>
          )}
        </div>
      )}
    </div>
  );
};

// --- Spending Ring Component ---
interface SpendingRingProps {
  label: string;
  amountPaise: number;
  limitPaise: number;
  color?: string;
  currencySymbol?: string;
  onClick?: () => void;
}

export const SpendingRing: React.FC<SpendingRingProps> = ({
  label,
  amountPaise,
  limitPaise,
  color = '#B6FF00',
  currencySymbol = '₹',
  onClick,
}) => {
  const percent = limitPaise > 0 ? Math.min(100, Math.round((amountPaise / limitPaise) * 100)) : 0;
  const radius = 32;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percent / 100) * circumference;

  return (
    <div
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      className={`flex flex-col items-center p-3 rounded-xl bg-[#121216] border border-[#27272A] transition-all ${
        onClick ? 'hover:border-[#B6FF00]/40 cursor-pointer active:scale-95' : ''
      }`}
    >
      <div className="relative w-20 h-20 flex items-center justify-center">
        <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 80 80">
          <circle
            cx="40"
            cy="40"
            r={radius}
            stroke="#1A1A22"
            strokeWidth="6"
            fill="transparent"
          />
          <circle
            cx="40"
            cy="40"
            r={radius}
            stroke={color}
            strokeWidth="6"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            fill="transparent"
            className="transition-all duration-700 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="text-[11px] font-bold font-amount text-white">{percent}%</span>
        </div>
      </div>
      <span className="text-xs font-medium text-[#A1A1AA] mt-1.5">{label}</span>
      <span className="text-xs font-bold font-amount text-white mt-0.5">
        {formatPaise(amountPaise, currencySymbol)}
      </span>
    </div>
  );
};

// --- Category Card Component ---
interface CategoryCardProps {
  category: ExpenseCategory;
  amountPaise: number;
  percentage?: number;
  currencySymbol?: string;
  onClick?: () => void;
}

export const CategoryCard: React.FC<CategoryCardProps> = ({
  category,
  amountPaise,
  percentage,
  currencySymbol = '₹',
  onClick,
}) => {
  const config = CATEGORY_CONFIG[category] || CATEGORY_CONFIG.Others;
  const Icon = config.icon;

  return (
    <button
      onClick={onClick}
      className="flex items-center justify-between p-3.5 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#B6FF00]/40 transition-all text-left w-full cursor-pointer active:scale-[0.99]"
    >
      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: config.bg, color: config.color }}
        >
          <Icon className="w-5 h-5" />
        </div>
        <div>
          <h4 className="text-sm font-semibold text-white">{category}</h4>
          {percentage !== undefined && (
            <span className="text-xs text-[#888888]">{percentage}% of spending</span>
          )}
        </div>
      </div>
      <div className="text-right">
        <span className="text-sm font-bold font-amount text-white block">
          {formatPaise(amountPaise, currencySymbol)}
        </span>
        <ChevronRight className="w-4 h-4 text-[#888888] inline-block ml-auto mt-0.5" />
      </div>
    </button>
  );
};

// --- Transaction List Item ---
interface TransactionListItemProps {
  expense: Expense;
  currencySymbol?: string;
  onClick?: () => void;
}

export const TransactionListItem: React.FC<TransactionListItemProps> = ({
  expense,
  currencySymbol = '₹',
  onClick,
}) => {
  const config = CATEGORY_CONFIG[expense.category] || CATEGORY_CONFIG.Others;
  const CategoryIcon = config.icon;
  const PaymentIcon = PAYMENT_METHOD_ICONS[expense.paymentMethod] || Smartphone;

  return (
    <div
      onClick={onClick}
      role="button"
      tabIndex={0}
      className="flex items-center justify-between p-3.5 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#B6FF00]/40 transition-all cursor-pointer active:scale-[0.99] group"
    >
      <div className="flex items-center gap-3 min-w-0">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
          style={{ backgroundColor: config.bg, color: config.color }}
        >
          <CategoryIcon className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-white truncate group-hover:text-[#B6FF00] transition-colors">
            {expense.merchant}
          </p>
          <div className="flex items-center gap-2 text-xs text-[#888888] mt-0.5">
            <span>{expense.category}</span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <PaymentIcon className="w-3 h-3 text-[#A1A1AA]" />
              {expense.paymentMethod}
            </span>
          </div>
        </div>
      </div>

      <div className="text-right shrink-0 pl-3">
        <p className="text-sm font-bold font-amount text-white">
          -{formatPaise(expense.amountPaise, currencySymbol)}
        </p>
        <p className="text-[11px] text-[#888888] mt-0.5">
          {expense.date}
        </p>
      </div>
    </div>
  );
};

// --- Budget Progress Card ---
interface BudgetProgressCardProps {
  budget: Budget;
  spentPaise: number;
  currencySymbol?: string;
  onClick?: () => void;
}

export const BudgetProgressCard: React.FC<BudgetProgressCardProps> = ({
  budget,
  spentPaise,
  currencySymbol = '₹',
  onClick,
}) => {
  const percent = budget.monthlyLimitPaise > 0
    ? Math.min(100, Math.round((spentPaise / budget.monthlyLimitPaise) * 100))
    : 0;
  const isOver = spentPaise > budget.monthlyLimitPaise;
  const isNear = percent >= 80 && !isOver;
  const remaining = budget.monthlyLimitPaise - spentPaise;

  const config =
    budget.category === 'Overall'
      ? { icon: Receipt, color: '#00F5FF', bg: 'rgba(0, 245, 255, 0.15)' }
      : CATEGORY_CONFIG[budget.category as ExpenseCategory] || CATEGORY_CONFIG.Others;
  const Icon = config.icon;

  return (
    <div
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      className={`p-4 rounded-xl bg-[#121216] border border-[#27272A] transition-all ${
        onClick ? 'hover:border-[#B6FF00]/40 cursor-pointer active:scale-[0.99]' : ''
      }`}
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: config.bg, color: config.color }}
          >
            <Icon className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-white">{budget.category}</h4>
            <span className="text-[11px] text-[#888888] capitalize">{budget.period} budget</span>
          </div>
        </div>

        <span
          className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
            isOver
              ? 'bg-[#FF2D78]/20 text-[#FF2D78] border border-[#FF2D78]/30'
              : isNear
              ? 'bg-[#FF5F1F]/20 text-[#FF5F1F] border border-[#FF5F1F]/30'
              : 'bg-[#B6FF00]/15 text-[#B6FF00] border border-[#B6FF00]/30'
          }`}
        >
          {isOver ? 'Exceeded' : `${percent}%`}
        </span>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-[#050505] rounded-full h-2 mb-2 overflow-hidden border border-[#27272A]">
        <div
          className={`h-full rounded-full transition-all duration-500 ${
            isOver ? 'bg-[#FF2D78]' : isNear ? 'bg-[#FF5F1F]' : 'bg-[#B6FF00]'
          }`}
          style={{ width: `${Math.min(100, percent)}%` }}
        />
      </div>

      <div className="flex items-center justify-between text-xs text-[#888888]">
        <span>
          Spent: <strong className="text-white font-amount">{formatPaise(spentPaise, currencySymbol)}</strong>
        </span>
        <span>
          Limit: <strong className="text-white font-amount">{formatPaise(budget.monthlyLimitPaise, currencySymbol)}</strong>
        </span>
      </div>
      {isOver ? (
        <p className="text-[11px] text-[#FF2D78] font-medium mt-2 flex items-center gap-1">
          <AlertTriangle className="w-3.5 h-3.5" />
          Over budget by {formatPaise(Math.abs(remaining), currencySymbol)}
        </p>
      ) : (
        <p className="text-[11px] text-[#A1A1AA] mt-1.5">
          {formatPaise(remaining, currencySymbol)} remaining
        </p>
      )}
    </div>
  );
};

// --- Empty State ---
interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  actionText?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  actionText,
  onAction,
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center rounded-2xl bg-[#121216] border border-[#27272A] my-4">
      <div className="w-14 h-14 rounded-2xl bg-[#1A1A22] border border-[#27272A] flex items-center justify-center text-[#B6FF00] mb-3 shadow-[0_0_15px_rgba(182,255,0,0.15)]">
        {icon || <Receipt className="w-7 h-7" />}
      </div>
      <h3 className="text-base font-semibold text-white mb-1">{title}</h3>
      <p className="text-xs text-[#888888] max-w-xs mb-4 leading-relaxed">{description}</p>
      {actionText && onAction && (
        <button
          onClick={onAction}
          className="py-2 px-4 rounded-xl bg-[#B6FF00] text-black font-semibold text-xs hover:bg-[#c4ff2e] cursor-pointer transition-all shadow-[0_0_10px_rgba(182,255,0,0.3)]"
        >
          {actionText}
        </button>
      )}
    </div>
  );
};

// --- Loading State ---
export const LoadingState: React.FC<{ message?: string }> = ({ message = 'Loading Selavu...' }) => {
  return (
    <div className="flex flex-col items-center justify-center p-12 text-center min-h-[200px]">
      <div className="w-14 h-14 rounded-2xl bg-[#121216] border border-[#B6FF00]/40 flex items-center justify-center animate-pulse glow-lime mb-3">
        <span className="text-2xl font-bold font-amount text-[#B6FF00]">₹</span>
      </div>
      <p className="text-xs text-[#A1A1AA] font-medium">{message}</p>
    </div>
  );
};

// --- Error Message ---
export const ErrorMessage: React.FC<{ message: string; onRetry?: () => void }> = ({
  message,
  onRetry,
}) => {
  return (
    <div className="p-4 rounded-xl bg-[#1A1215] border border-[#FF2D78]/40 flex items-start gap-3 my-3">
      <AlertTriangle className="w-5 h-5 text-[#FF2D78] shrink-0 mt-0.5" />
      <div className="flex-1">
        <p className="text-xs text-[#FF2D78] font-medium">{message}</p>
        {onRetry && (
          <button
            onClick={onRetry}
            className="text-xs text-white underline mt-1.5 cursor-pointer hover:text-[#B6FF00]"
          >
            Try Again
          </button>
        )}
      </div>
    </div>
  );
};
