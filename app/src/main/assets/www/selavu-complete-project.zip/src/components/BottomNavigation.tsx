import React from 'react';
import { Home, History, PieChart, Wallet, User } from 'lucide-react';
import { PageName } from '../types';

interface BottomNavigationProps {
  currentPage: PageName;
  onNavigate: (page: PageName) => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  currentPage,
  onNavigate,
}) => {
  const navItems = [
    { page: 'HomePage' as PageName, label: 'Home', icon: Home },
    { page: 'HistoryPage' as PageName, label: 'History', icon: History },
    { page: 'BudgetsPage' as PageName, label: 'Budgets', icon: Wallet },
    { page: 'AnalyticsPage' as PageName, label: 'Analytics', icon: PieChart },
    { page: 'ProfilePage' as PageName, label: 'Profile', icon: User },
  ];

  return (
    <nav
      aria-label="Bottom Navigation"
      className="sticky bottom-0 left-0 right-0 z-40 w-full bg-[#0B0B0F]/95 backdrop-blur-lg border-t border-[#27272A] px-2 py-2.5 flex items-center justify-around shadow-[0_-8px_20px_rgba(0,0,0,0.6)] select-none shrink-0"
    >
      {navItems.map((item) => {
        const Icon = item.icon;
        const isActive = currentPage === item.page;

        return (
          <button
            key={item.page}
            onClick={() => onNavigate(item.page)}
            className={`flex flex-col items-center justify-center py-1 px-3 rounded-xl transition-all cursor-pointer ${
              isActive
                ? 'text-[#B6FF00]'
                : 'text-[#888888] hover:text-[#A1A1AA]'
            }`}
          >
            <div className={`relative ${isActive ? 'scale-110' : ''} transition-transform`}>
              <Icon className="w-5 h-5" />
              {isActive && (
                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-[#B6FF00] shadow-[0_0_6px_#B6FF00]" />
              )}
            </div>
            <span className="text-[10px] font-medium mt-1">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
