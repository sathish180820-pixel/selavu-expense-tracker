import React from 'react';
import { ArrowLeft, X } from 'lucide-react';

interface AppHeaderProps {
  title: string;
  tamilSubtitle?: string;
  showBack?: boolean;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  closeIcon?: boolean;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  title,
  tamilSubtitle,
  showBack = false,
  onBack,
  rightAction,
  closeIcon = false,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-[#050505]/90 backdrop-blur-md border-b border-[#27272A]/80 px-4 py-3 flex items-center justify-between select-none">
      <div className="flex items-center gap-3 min-w-0">
        {showBack && (
          <button
            onClick={onBack}
            aria-label={closeIcon ? 'Close' : 'Go back'}
            className="w-9 h-9 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#B6FF00]/50 text-white flex items-center justify-center cursor-pointer transition-colors active:scale-95 shrink-0"
          >
            {closeIcon ? <X className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
          </button>
        )}
        <div className="min-w-0">
          <h1 className="text-base sm:text-lg font-bold text-white truncate tracking-tight flex items-center gap-2">
            <span>{title}</span>
            {tamilSubtitle && (
              <span className="text-xs font-normal font-tamil text-[#A1A1AA]">
                ({tamilSubtitle})
              </span>
            )}
          </h1>
        </div>
      </div>

      {rightAction && (
        <div className="shrink-0 flex items-center gap-1">
          {rightAction}
        </div>
      )}
    </header>
  );
};
