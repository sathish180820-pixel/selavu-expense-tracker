import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserProfile,
  Expense,
  Budget,
  AppSettings,
  PageName,
  NavigationState,
  ExpenseCategory,
  PaymentMethod,
} from '../types';
import { rupeesToPaise } from '../utils/finance';

const STORAGE_KEY = 'selavu_expense_tracker_v1';

const DEFAULT_PROFILE: UserProfile = {
  id: 'usr_default',
  name: 'Sathish Kumar',
  email: 'sathish180820@gmail.com',
  monthlySalaryPaise: rupeesToPaise(75000), // ₹75,000
  savingsGoalPaise: rupeesToPaise(25000),  // ₹25,000
  currencySymbol: '₹',
  currencyCode: 'INR',
  onboardingComplete: false, // will show splash -> onboarding by default, or auto-complete when setup
  avatarSeed: 'sathish',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

const DEFAULT_BUDGETS: Budget[] = [
  {
    id: 'b_overall',
    category: 'Overall',
    monthlyLimitPaise: rupeesToPaise(50000), // ₹50,000
    period: 'monthly',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'b_food',
    category: 'Food & Dining',
    monthlyLimitPaise: rupeesToPaise(12000), // ₹12,000
    period: 'monthly',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'b_groceries',
    category: 'Groceries',
    monthlyLimitPaise: rupeesToPaise(10000), // ₹10,000
    period: 'monthly',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'b_bills',
    category: 'Bills & Utilities',
    monthlyLimitPaise: rupeesToPaise(8000), // ₹8,000
    period: 'monthly',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'b_transport',
    category: 'Transport',
    monthlyLimitPaise: rupeesToPaise(6000), // ₹6,000
    period: 'monthly',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

const DEFAULT_EXPENSES: Expense[] = [
  {
    id: 'exp_1',
    amountPaise: rupeesToPaise(650),
    category: 'Food & Dining',
    merchant: 'Murugan Idli Shop',
    paymentMethod: 'UPI',
    date: '2026-10-26',
    time: '08:45',
    notes: 'Breakfast with friends - Ghee Podi Idli',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'exp_2',
    amountPaise: rupeesToPaise(240),
    category: 'Transport',
    merchant: 'Chennai Metro Rail',
    paymentMethod: 'UPI',
    date: '2026-10-26',
    time: '10:15',
    notes: 'Smartcard top-up for weekly commute',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'exp_3',
    amountPaise: rupeesToPaise(1850),
    category: 'Groceries',
    merchant: 'Nilgiris Supermarket',
    paymentMethod: 'Credit Card',
    date: '2026-10-25',
    time: '19:20',
    notes: 'Weekly fresh vegetables and dairy supplies',
    createdAt: new Date(Date.now() - 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: 'exp_4',
    amountPaise: rupeesToPaise(1199),
    category: 'Bills & Utilities',
    merchant: 'JioFiber Broadband',
    paymentMethod: 'Net Banking',
    date: '2026-10-23',
    time: '14:30',
    notes: 'Monthly Gigabit internet bill',
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 86400000).toISOString(),
  },
  {
    id: 'exp_5',
    amountPaise: rupeesToPaise(550),
    category: 'Entertainment',
    merchant: 'PVR Cinemas VR Mall',
    paymentMethod: 'UPI',
    date: '2026-10-22',
    time: '21:00',
    notes: 'Movie tickets with popcorn',
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 4 * 86400000).toISOString(),
  },
  {
    id: 'exp_6',
    amountPaise: rupeesToPaise(3200),
    category: 'Shopping',
    merchant: 'Zudio Phoenix Marketcity',
    paymentMethod: 'Credit Card',
    date: '2026-10-18',
    time: '17:10',
    notes: 'Festival casual shirts & wear',
    createdAt: new Date(Date.now() - 8 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 8 * 86400000).toISOString(),
  },
  {
    id: 'exp_7',
    amountPaise: rupeesToPaise(420),
    category: 'Health',
    merchant: 'Apollo Pharmacy',
    paymentMethod: 'UPI',
    date: '2026-10-15',
    time: '11:20',
    notes: 'Multivitamins and first-aid supplies',
    createdAt: new Date(Date.now() - 11 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 11 * 86400000).toISOString(),
  },
];

const DEFAULT_SETTINGS: AppSettings = {
  currencySymbol: '₹',
  currencyCode: 'INR',
  notificationsEnabled: true,
  biometricLock: false,
  soundEffects: true,
  theme: 'neon-dark',
  language: 'ta-en',
  lastBackupDate: undefined,
};

interface AppContextType {
  profile: UserProfile;
  expenses: Expense[];
  budgets: Budget[];
  settings: AppSettings;
  navigation: NavigationState;
  historyStack: NavigationState[];
  navigate: (page: PageName, params?: NavigationState['params']) => void;
  goBack: () => void;
  saveProfile: (updates: Partial<UserProfile>) => void;
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt' | 'updatedAt'>) => Expense;
  updateExpense: (id: string, updates: Partial<Omit<Expense, 'id' | 'createdAt' | 'updatedAt'>>) => void;
  deleteExpense: (id: string) => void;
  addBudget: (budget: Omit<Budget, 'id' | 'createdAt' | 'updatedAt'>) => Budget;
  updateBudget: (id: string, updates: Partial<Omit<Budget, 'id' | 'createdAt' | 'updatedAt'>>) => void;
  deleteBudget: (id: string) => void;
  updateSettings: (updates: Partial<AppSettings>) => void;
  resetAllData: () => void;
  seedSampleData: () => void;
  importBackup: (backupJson: string) => { success: boolean; error?: string };
  exportBackup: () => string;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Check URL query parameters for direct page jumps or ?autostart=1
  const initialParams = new URLSearchParams(window.location.search);
  const autostart = initialParams.get('autostart') === '1';
  const targetPageQuery = initialParams.get('page') as PageName | null;

  const [profile, setProfile] = useState<UserProfile>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY}_profile`);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn('Failed to load profile from storage', e);
    }
    return DEFAULT_PROFILE;
  });

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY}_expenses`);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn('Failed to load expenses from storage', e);
    }
    return DEFAULT_EXPENSES;
  });

  const [budgets, setBudgets] = useState<Budget[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY}_budgets`);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn('Failed to load budgets from storage', e);
    }
    return DEFAULT_BUDGETS;
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_KEY}_settings`);
      if (stored) return JSON.parse(stored);
    } catch (e) {
      console.warn('Failed to load settings from storage', e);
    }
    return DEFAULT_SETTINGS;
  });

  const getInitialPage = (): PageName => {
    if (targetPageQuery) return targetPageQuery;
    if (autostart) {
      return profile.onboardingComplete ? 'HomePage' : 'OnboardingWelcomePage';
    }
    return 'SplashPage';
  };

  const [navigation, setNavigation] = useState<NavigationState>({
    currentPage: getInitialPage(),
    previousPage: undefined,
    params: {},
  });

  const [historyStack, setHistoryStack] = useState<NavigationState[]>([]);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_profile`, JSON.stringify(profile));
    } catch (e) {
      console.error('Failed to save profile', e);
    }
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_expenses`, JSON.stringify(expenses));
    } catch (e) {
      console.error('Failed to save expenses', e);
    }
  }, [expenses]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_budgets`, JSON.stringify(budgets));
    } catch (e) {
      console.error('Failed to save budgets', e);
    }
  }, [budgets]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_settings`, JSON.stringify(settings));
    } catch (e) {
      console.error('Failed to save settings', e);
    }
  }, [settings]);

  const navigate = (page: PageName, params?: NavigationState['params']) => {
    setHistoryStack((prev) => [...prev, navigation]);
    setNavigation({
      currentPage: page,
      previousPage: navigation.currentPage,
      params: params || {},
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const goBack = () => {
    if (historyStack.length > 0) {
      const nextStack = [...historyStack];
      const previousState = nextStack.pop()!;
      setHistoryStack(nextStack);
      setNavigation(previousState);
    } else {
      // Default fallback
      if (navigation.currentPage === 'SplashPage') return;
      if (['ProfileSetupPage', 'SavingsGoalPage'].includes(navigation.currentPage)) {
        navigate('OnboardingWelcomePage');
      } else if (navigation.currentPage === 'HomePage') {
        // Stay on home
      } else {
        navigate('HomePage');
      }
    }
  };

  const saveProfile = (updates: Partial<UserProfile>) => {
    setProfile((prev) => ({
      ...prev,
      ...updates,
      updatedAt: new Date().toISOString(),
    }));
  };

  const addExpense = (data: Omit<Expense, 'id' | 'createdAt' | 'updatedAt'>): Expense => {
    const newExpense: Expense = {
      ...data,
      id: `exp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setExpenses((prev) => [newExpense, ...prev]);
    return newExpense;
  };

  const updateExpense = (id: string, updates: Partial<Omit<Expense, 'id' | 'createdAt' | 'updatedAt'>>) => {
    setExpenses((prev) =>
      prev.map((exp) => (exp.id === id ? { ...exp, ...updates, updatedAt: new Date().toISOString() } : exp))
    );
  };

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((exp) => exp.id !== id));
  };

  const addBudget = (data: Omit<Budget, 'id' | 'createdAt' | 'updatedAt'>): Budget => {
    const newBudget: Budget = {
      ...data,
      id: `b_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setBudgets((prev) => [...prev, newBudget]);
    return newBudget;
  };

  const updateBudget = (id: string, updates: Partial<Omit<Budget, 'id' | 'createdAt' | 'updatedAt'>>) => {
    setBudgets((prev) =>
      prev.map((b) => (b.id === id ? { ...b, ...updates, updatedAt: new Date().toISOString() } : b))
    );
  };

  const deleteBudget = (id: string) => {
    setBudgets((prev) => prev.filter((b) => b.id !== id));
  };

  const updateSettings = (updates: Partial<AppSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...updates };
      if (updates.currencySymbol && updates.currencySymbol !== profile.currencySymbol) {
        saveProfile({ currencySymbol: updates.currencySymbol, currencyCode: updates.currencyCode || profile.currencyCode });
      }
      return updated;
    });
  };

  const resetAllData = () => {
    localStorage.removeItem(`${STORAGE_KEY}_profile`);
    localStorage.removeItem(`${STORAGE_KEY}_expenses`);
    localStorage.removeItem(`${STORAGE_KEY}_budgets`);
    localStorage.removeItem(`${STORAGE_KEY}_settings`);
    setProfile({
      ...DEFAULT_PROFILE,
      onboardingComplete: false,
    });
    setExpenses([]);
    setBudgets([]);
    setSettings(DEFAULT_SETTINGS);
  };

  const seedSampleData = () => {
    setProfile({
      ...DEFAULT_PROFILE,
      onboardingComplete: true,
    });
    setExpenses(DEFAULT_EXPENSES);
    setBudgets(DEFAULT_BUDGETS);
    setSettings(DEFAULT_SETTINGS);
  };

  const exportBackup = (): string => {
    const backupObj = {
      version: 1,
      appName: 'Selavu (செலவு)',
      exportTimestamp: new Date().toISOString(),
      profile,
      expenses,
      budgets,
      settings,
    };
    updateSettings({ lastBackupDate: new Date().toISOString() });
    return JSON.stringify(backupObj, null, 2);
  };

  const importBackup = (backupJson: string): { success: boolean; error?: string } => {
    try {
      const parsed = JSON.parse(backupJson);
      if (!parsed.expenses || !Array.isArray(parsed.expenses)) {
        return { success: false, error: 'Invalid backup: missing expenses array' };
      }
      if (!parsed.profile || typeof parsed.profile !== 'object') {
        return { success: false, error: 'Invalid backup: missing profile data' };
      }

      if (parsed.profile) setProfile(parsed.profile);
      if (Array.isArray(parsed.expenses)) setExpenses(parsed.expenses);
      if (Array.isArray(parsed.budgets)) setBudgets(parsed.budgets);
      if (parsed.settings) setSettings(parsed.settings);

      return { success: true };
    } catch (e: unknown) {
      return { success: false, error: e instanceof Error ? e.message : 'Invalid JSON file' };
    }
  };

  return (
    <AppContext.Provider
      value={{
        profile,
        expenses,
        budgets,
        settings,
        navigation,
        historyStack,
        navigate,
        goBack,
        saveProfile,
        addExpense,
        updateExpense,
        deleteExpense,
        addBudget,
        updateBudget,
        deleteBudget,
        updateSettings,
        resetAllData,
        seedSampleData,
        importBackup,
        exportBackup,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
