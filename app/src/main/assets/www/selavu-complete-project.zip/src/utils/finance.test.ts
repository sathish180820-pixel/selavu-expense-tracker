import test from 'node:test';
import assert from 'node:assert/strict';
import {
  rupeesToPaise,
  paiseToRupees,
  formatRupees,
  calculateMonthlyAllowance,
  calculateRemainingAllowance,
  calculateBudgetStatus,
  calculatePeriodTotals,
  getCategoryTotals,
  generateExpensesCSV,
  validateBackupData,
} from './finance';
import { Expense } from '../types';

test('rupeesToPaise converts numbers and strings accurately to integer paise', () => {
  assert.equal(rupeesToPaise(100), 10000);
  assert.equal(rupeesToPaise('45.50'), 4550);
  assert.equal(rupeesToPaise(0), 0);
  assert.equal(rupeesToPaise(-5), 0);
});

test('paiseToRupees converts integer paise back to rupees correctly', () => {
  assert.equal(paiseToRupees(10000), 100);
  assert.equal(paiseToRupees(4550), 45.5);
  assert.equal(paiseToRupees(0), 0);
});

test('formatRupees formats currency with Rupee symbol and Indian comma styling', () => {
  assert.equal(formatRupees(150000), '₹1,50,000');
  assert.equal(formatRupees(450), '₹450');
  assert.equal(formatRupees(-500), '-₹500');
});

test('allowance calculations compute salary minus savings goal and remaining balance', () => {
  const salaryPaise = 75000 * 100; // 75,000
  const savingsGoalPaise = 20000 * 100; // 20,000
  const monthlyAllowance = calculateMonthlyAllowance(salaryPaise, savingsGoalPaise);
  assert.equal(monthlyAllowance, 55000 * 100);

  const expensesPaise = 15000 * 100; // 15,000
  const remainingAllowance = calculateRemainingAllowance(salaryPaise, savingsGoalPaise, expensesPaise);
  assert.equal(remainingAllowance, 40000 * 100);
});

test('budget status accurately reports percentages and overrun', () => {
  const limitPaise = 10000 * 100;
  const spentPaise = 6000 * 100;
  const normalStatus = calculateBudgetStatus(spentPaise, limitPaise);
  assert.equal(normalStatus.percent, 60);
  assert.equal(normalStatus.isOver, false);
  assert.equal(normalStatus.remainingPaise, 4000 * 100);

  const overspentStatus = calculateBudgetStatus(12000 * 100, limitPaise);
  assert.equal(overspentStatus.percent, 100);
  assert.equal(overspentStatus.isOver, true);
  assert.equal(overspentStatus.remainingPaise, -2000 * 100);
});

test('calculatePeriodTotals sums daily, weekly, and monthly expenses accurately', () => {
  const refDate = new Date('2026-10-26T12:00:00');
  const dummyExpenses: Expense[] = [
    {
      id: '1',
      amountPaise: 50000, // 500
      category: 'Food & Dining',
      merchant: 'Saravana Bhavan',
      paymentMethod: 'UPI',
      date: '2026-10-26',
      time: '12:30',
      createdAt: '2026-10-26T12:30:00Z',
      updatedAt: '2026-10-26T12:30:00Z',
    },
    {
      id: '2',
      amountPaise: 30000, // 300
      category: 'Transport',
      merchant: 'Metro Rail',
      paymentMethod: 'UPI',
      date: '2026-10-25',
      time: '09:00',
      createdAt: '2026-10-25T09:00:00Z',
      updatedAt: '2026-10-25T09:00:00Z',
    },
    {
      id: '3',
      amountPaise: 200000, // 2000
      category: 'Bills & Utilities',
      merchant: 'TNEB Electricity',
      paymentMethod: 'Net Banking',
      date: '2026-10-05',
      time: '14:00',
      createdAt: '2026-10-05T14:00:00Z',
      updatedAt: '2026-10-05T14:00:00Z',
    },
  ];

  const totals = calculatePeriodTotals(dummyExpenses, refDate);
  assert.equal(totals.dailyPaise, 50000); // 500
  assert.equal(totals.weeklyPaise, 80000); // 500 + 300
  assert.equal(totals.monthlyPaise, 280000); // 500 + 300 + 2000
});

test('CSV export and backup validation generate valid structures', () => {
  const dummyExpenses: Expense[] = [
    {
      id: 'e1',
      amountPaise: 25000,
      category: 'Groceries',
      merchant: 'Nilgiris Supermarket',
      paymentMethod: 'Credit Card',
      date: '2026-10-20',
      time: '18:00',
      notes: 'Weekly grocery supplies',
      createdAt: '2026-10-20T18:00:00Z',
      updatedAt: '2026-10-20T18:00:00Z',
    },
  ];

  const csv = generateExpensesCSV(dummyExpenses);
  assert.ok(csv.includes('Nilgiris Supermarket'));
  assert.ok(csv.includes('250.00'));

  const validBackup = validateBackupData({
    expenses: dummyExpenses,
    profile: { name: 'Sathish', monthlySalaryPaise: 5000000 },
  });
  assert.equal(validBackup.valid, true);

  const invalidBackup = validateBackupData({ foo: 'bar' });
  assert.equal(invalidBackup.valid, false);
});
