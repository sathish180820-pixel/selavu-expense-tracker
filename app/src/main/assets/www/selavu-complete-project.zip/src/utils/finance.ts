import { Expense, ExpenseCategory } from '../types';

/**
 * Converts Indian Rupees (can be decimal) to integer paise to prevent floating-point inaccuracies
 */
export function rupeesToPaise(rupees: number | string): number {
  const num = typeof rupees === 'string' ? parseFloat(rupees) : rupees;
  if (isNaN(num) || num <= 0) return 0;
  return Math.round(num * 100);
}

/**
 * Converts integer paise back to Rupee float
 */
export function paiseToRupees(paise: number): number {
  if (!paise || isNaN(paise)) return 0;
  return paise / 100;
}

/**
 * Formats Rupee amounts with Indian Numbering system (e.g., ₹1,50,000 or ₹450)
 */
export function formatRupees(amountInRupees: number, currencySymbol = '₹'): string {
  const isNegative = amountInRupees < 0;
  const absAmount = Math.abs(amountInRupees);
  
  // Format with en-IN locale
  const formatted = new Intl.NumberFormat('en-IN', {
    maximumFractionDigits: 2,
    minimumFractionDigits: absAmount % 1 !== 0 ? 2 : 0,
  }).format(absAmount);
  
  return `${isNegative ? '-' : ''}${currencySymbol}${formatted}`;
}

export function formatPaise(paise: number, currencySymbol = '₹'): string {
  return formatRupees(paiseToRupees(paise), currencySymbol);
}

/**
 * Calculate Monthly Allowance = Salary - Savings Goal
 */
export function calculateMonthlyAllowance(salaryPaise: number, savingsGoalPaise: number): number {
  return Math.max(0, salaryPaise - savingsGoalPaise);
}

/**
 * Calculate Remaining Allowance = Salary - Savings Goal - Monthly Expenses
 */
export function calculateRemainingAllowance(
  salaryPaise: number,
  savingsGoalPaise: number,
  monthlyExpensesPaise: number
): number {
  return salaryPaise - savingsGoalPaise - monthlyExpensesPaise;
}

/**
 * Calculate Budget Status
 */
export function calculateBudgetStatus(spentPaise: number, limitPaise: number) {
  if (limitPaise <= 0) {
    return {
      percent: 0,
      isOver: false,
      remainingPaise: 0,
      ratio: 0,
    };
  }
  const ratio = spentPaise / limitPaise;
  const percent = Math.min(100, Math.round(ratio * 100));
  const remainingPaise = limitPaise - spentPaise;
  return {
    percent,
    isOver: spentPaise > limitPaise,
    remainingPaise,
    ratio,
  };
}

/**
 * Aggregates daily, weekly, monthly totals for expenses
 */
export function calculatePeriodTotals(expenses: Expense[], refDate = new Date()) {
  const refYear = refDate.getFullYear();
  const refMonth = refDate.getMonth();
  const refDay = refDate.getDate();

  // Today string YYYY-MM-DD
  const yyyy = refYear;
  const mm = String(refMonth + 1).padStart(2, '0');
  const dd = String(refDay).padStart(2, '0');
  const todayStr = `${yyyy}-${mm}-${dd}`;

  // Start of current week (assume Monday as start or 7 days back)
  const oneWeekAgo = new Date(refDate);
  oneWeekAgo.setDate(refDate.getDate() - 7);

  let dailyPaise = 0;
  let weeklyPaise = 0;
  let monthlyPaise = 0;

  for (const exp of expenses) {
    const expDate = new Date(exp.date + 'T00:00:00');
    // Check if same day
    if (exp.date === todayStr) {
      dailyPaise += exp.amountPaise;
    }
    // Check if within last 7 days
    if (expDate >= oneWeekAgo && expDate <= refDate) {
      weeklyPaise += exp.amountPaise;
    }
    // Check if same year and month
    if (expDate.getFullYear() === refYear && expDate.getMonth() === refMonth) {
      monthlyPaise += exp.amountPaise;
    }
  }

  return {
    dailyPaise,
    weeklyPaise,
    monthlyPaise,
  };
}

/**
 * Group expenses by category
 */
export function getCategoryTotals(expenses: Expense[]): Record<ExpenseCategory, number> {
  const totals: Record<string, number> = {};
  for (const exp of expenses) {
    totals[exp.category] = (totals[exp.category] || 0) + exp.amountPaise;
  }
  return totals as Record<ExpenseCategory, number>;
}

/**
 * Generate CSV export
 */
export function generateExpensesCSV(expenses: Expense[], currencyCode = 'INR'): string {
  const headers = ['ID', 'Date', 'Time', 'Merchant', 'Category', 'Payment Method', `Amount (${currencyCode})`, 'Notes'];
  const rows = expenses.map((exp) => [
    `"${exp.id}"`,
    `"${exp.date}"`,
    `"${exp.time}"`,
    `"${(exp.merchant || '').replace(/"/g, '""')}"`,
    `"${exp.category}"`,
    `"${exp.paymentMethod}"`,
    paiseToRupees(exp.amountPaise).toFixed(2),
    `"${(exp.notes || '').replace(/"/g, '""')}"`,
  ]);

  return [headers.join(','), ...rows.map((r) => r.join(','))].join('\r\n');
}

/**
 * Validate backup JSON data
 */
export function validateBackupData(data: unknown): { valid: boolean; error?: string } {
  if (!data || typeof data !== 'object') {
    return { valid: false, error: 'Backup data must be an object' };
  }
  const obj = data as Record<string, unknown>;
  if (!Array.isArray(obj.expenses)) {
    return { valid: false, error: 'Backup is missing valid "expenses" list' };
  }
  if (!obj.profile || typeof obj.profile !== 'object') {
    return { valid: false, error: 'Backup is missing valid "profile" object' };
  }
  return { valid: true };
}
