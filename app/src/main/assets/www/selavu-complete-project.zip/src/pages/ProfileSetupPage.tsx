import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { NeonPrimaryButton, ErrorMessage } from '../components/UIComponents';
import { AppHeader } from '../components/AppHeader';
import { User, DollarSign, ArrowRight } from 'lucide-react';
import { paiseToRupees, rupeesToPaise, formatRupees } from '../utils/finance';

export const ProfileSetupPage: React.FC = () => {
  const { profile, saveProfile, navigate } = useApp();
  const [name, setName] = useState(profile.name || '');
  const [salaryStr, setSalaryStr] = useState(
    profile.monthlySalaryPaise > 0 ? paiseToRupees(profile.monthlySalaryPaise).toString() : '75000'
  );
  const [error, setError] = useState<string | null>(null);

  const handleContinue = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!name.trim()) {
      setError('Please enter your full name');
      return;
    }
    const salaryNum = parseFloat(salaryStr);
    if (isNaN(salaryNum) || salaryNum <= 0) {
      setError('Please enter a valid monthly salary');
      return;
    }

    setError(null);
    saveProfile({
      name: name.trim(),
      monthlySalaryPaise: rupeesToPaise(salaryNum),
    });
    navigate('SavingsGoalPage');
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="profile-setup-page"
    >
      <AppHeader
        title="Profile Setup"
        tamilSubtitle="சுயவிவரம்"
        showBack={true}
        onBack={() => navigate('OnboardingWelcomePage')}
      />

      <div className="flex-1 max-w-sm mx-auto w-full px-5 py-6 flex flex-col justify-center">
        <div className="mb-6">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#00F5FF]">
            Step 2 of 3
          </span>
          <h2 className="text-2xl font-bold text-white mt-1">Let's Get Acquainted</h2>
          <p className="text-xs text-[#A1A1AA] mt-1">
            We use your monthly income to compute your allowable spending and safe daily budgets.
          </p>
        </div>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleContinue} className="space-y-5">
          {/* Name Field */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
              Your Name / பெயர்
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#888888]">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Sathish Kumar"
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-[#555] outline-none transition-all"
                required
              />
            </div>
          </div>

          {/* Monthly Salary Field */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
              Monthly Salary / மாத வருமானம் ({profile.currencySymbol})
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#B6FF00] font-bold text-base">
                ₹
              </div>
              <input
                type="number"
                min="1000"
                step="500"
                value={salaryStr}
                onChange={(e) => setSalaryStr(e.target.value)}
                placeholder="75000"
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-4 py-3 text-base font-amount text-white placeholder-[#555] outline-none transition-all"
                required
              />
            </div>

            {/* Quick salary chips */}
            <div className="flex items-center gap-2 mt-2.5 overflow-x-auto pb-1">
              {[25000, 50000, 75000, 100000, 150000].map((quick) => (
                <button
                  key={quick}
                  type="button"
                  onClick={() => setSalaryStr(quick.toString())}
                  className={`text-xs py-1 px-2.5 rounded-lg border font-amount transition-colors cursor-pointer shrink-0 ${
                    salaryStr === quick.toString()
                      ? 'bg-[#B6FF00]/20 text-[#B6FF00] border-[#B6FF00]'
                      : 'bg-[#121216] text-[#A1A1AA] border-[#27272A] hover:border-[#888]'
                  }`}
                >
                  ₹{quick / 1000}k
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4">
            <NeonPrimaryButton
              type="submit"
              icon={<ArrowRight className="w-4 h-4" />}
              data-testid="profile-continue-button"
            >
              Continue to Savings Goal
            </NeonPrimaryButton>
          </div>
        </form>
      </div>

      <DeveloperFooter />
    </div>
  );
};
