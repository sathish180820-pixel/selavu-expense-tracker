import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import { NeonPrimaryButton } from '../components/UIComponents';
import { generateExpensesCSV } from '../utils/finance';
import { FileSpreadsheet, Download, CheckCircle2, Table } from 'lucide-react';

export const ExportDataPage: React.FC = () => {
  const { profile, expenses, navigate } = useApp();
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [selectedRange, setSelectedRange] = useState<'all' | 'this_month' | 'last_30_days'>('all');

  const filteredExpenses = expenses.filter((e) => {
    if (selectedRange === 'all') return true;
    const now = new Date();
    const d = new Date(e.date + 'T00:00:00');
    if (selectedRange === 'this_month') {
      return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
    }
    if (selectedRange === 'last_30_days') {
      const past30 = new Date();
      past30.setDate(now.getDate() - 30);
      return d >= past30;
    }
    return true;
  });

  const handleExportCSV = () => {
    const csvContent = generateExpensesCSV(filteredExpenses, profile.currencyCode);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const today = new Date().toISOString().split('T')[0];
    a.href = url;
    a.download = `selavu_expenses_${selectedRange}_${today}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 5000);
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="export-data-page"
    >
      <AppHeader
        title="Export CSV Data"
        tamilSubtitle="ஏற்றுமதி"
        showBack={true}
        onBack={() => navigate('SettingsPage')}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {downloadSuccess && (
          <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/40 text-emerald-400 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>CSV spreadsheet successfully generated and saved to your device!</span>
          </div>
        )}

        {/* Export Overview Card */}
        <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-5 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#FF2D78]/15 text-[#FF2D78] flex items-center justify-center">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Universal CSV Export</h3>
              <p className="text-xs text-[#888888]">Compatible with Microsoft Excel, Google Sheets & Numbers</p>
            </div>
          </div>

          <div className="pt-2 border-t border-[#27272A] text-xs text-[#A1A1AA]">
            Exports {filteredExpenses.length} transactions with ID, Date, Time, Merchant, Category, Payment Method, Amount ({profile.currencyCode}), and Notes.
          </div>
        </div>

        {/* Range Selector */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold uppercase tracking-wider text-[#888888]">
            Select Export Period
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[
              { id: 'all', label: 'All Records' },
              { id: 'this_month', label: 'This Month' },
              { id: 'last_30_days', label: 'Last 30 Days' },
            ].map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setSelectedRange(opt.id as typeof selectedRange)}
                className={`py-2 px-1 text-xs rounded-xl border text-center font-medium transition-all cursor-pointer ${
                  selectedRange === opt.id
                    ? 'bg-[#FF2D78]/20 text-[#FF2D78] border-[#FF2D78]'
                    : 'bg-[#121216] text-[#A1A1AA] border-[#27272A]'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Preview of Columns */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-4 space-y-3">
          <div className="flex items-center gap-2 text-xs font-semibold text-white">
            <Table className="w-4 h-4 text-[#00F5FF]" />
            <span>Export Columns Schema</span>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {['ID', 'Date', 'Time', 'Merchant', 'Category', 'Payment Method', 'Amount', 'Notes'].map((col) => (
              <span
                key={col}
                className="text-[11px] font-mono py-1 px-2.5 rounded-lg bg-[#0B0B0F] text-[#CCC] border border-[#27272A]"
              >
                {col}
              </span>
            ))}
          </div>
        </div>

        {/* Export Button */}
        <div className="pt-2">
          <NeonPrimaryButton
            onClick={handleExportCSV}
            variant="pink"
            icon={<Download className="w-4 h-4" />}
            data-testid="export-csv-button"
          >
            Export & Download CSV ({filteredExpenses.length} rows)
          </NeonPrimaryButton>
        </div>

        <DeveloperFooter />
      </main>
    </div>
  );
};
