import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import {
  FinancialSummaryCard,
  SpendingRing,
  TransactionListItem,
  EmptyState,
} from '../components/UIComponents';
import { BottomNavigation } from '../components/BottomNavigation';
import {
  Plus,
  ArrowRight,
  User,
  SlidersHorizontal,
  TrendingUp,
  Receipt,
  Wallet,
} from 'lucide-react';
import { calculatePeriodTotals, paiseToRupees } from '../utils/finance';

export const HomePage: React.FC = () => {
  const { profile, expenses, budgets, navigate } = useApp();
  const [selectedRingPeriod, setSelectedRingPeriod] = useState<'daily' | 'weekly' | 'monthly'>('daily');

  // Calculate live numbers
  const periodTotals = calculatePeriodTotals(expenses);
  const monthlySalary = profile.monthlySalaryPaise;
  const savingsGoal = profile.savingsGoalPaise;
  const monthlyAllowance = Math.max(0, monthlySalary - savingsGoal);

  // Targets for spending rings
  const dailyTargetPaise = Math.round(monthlyAllowance / 30);
  const weeklyTargetPaise = Math.round(monthlyAllowance / 4.3);
  const monthlyTargetPaise = monthlyAllowance;

  // Recent 5 transactions
  const recentTransactions = expenses.slice(0, 5);

  return (
    <div
      className="relative min-h-full w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="home-page"
    >
      {/* Top App Bar with User Greeting & Profile Avatar */}
      <header className="sticky top-0 z-40 bg-[#050505]/95 backdrop-blur-md border-b border-[#27272A]/80 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('ProfilePage')}
            aria-label="View Profile"
            className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#1A1A22] to-[#27272A] border border-[#B6FF00]/50 flex items-center justify-center text-white cursor-pointer hover:scale-105 transition-all shadow-[0_0_10px_rgba(182,255,0,0.2)]"
          >
            <span className="font-bold text-sm font-amount text-[#B6FF00]">
              {profile.name ? profile.name.charAt(0).toUpperCase() : 'S'}
            </span>
          </button>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-[#888888]">Vanakkam,</span>
              <span className="text-xs font-semibold text-white">{profile.name}</span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-[#A1A1AA]">
              <span className="font-tamil text-[#B6FF00]">செலவு</span>
              <span>• Dashboard</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('SettingsPage')}
            aria-label="Settings"
            className="w-9 h-9 rounded-xl bg-[#121216] border border-[#27272A] text-[#A1A1AA] hover:text-[#B6FF00] hover:border-[#B6FF00]/40 flex items-center justify-center cursor-pointer transition-colors"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Scrollable Content */}
      <main className="max-w-md mx-auto w-full px-4 pt-4 space-y-5">
        {/* Financial Summary Card */}
        <FinancialSummaryCard
          salaryPaise={monthlySalary}
          savingsGoalPaise={savingsGoal}
          monthlyExpensesPaise={periodTotals.monthlyPaise}
          currencySymbol={profile.currencySymbol}
          onViewAnalytics={() => navigate('AnalyticsPage')}
          onManageBudgets={() => navigate('BudgetsPage')}
        />

        {/* Quick Add Expense Action Button */}
        <button
          onClick={() => navigate('AddExpensePage')}
          className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#B6FF00] to-[#00F5FF] text-black font-bold text-sm flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(182,255,0,0.25)] hover:shadow-[0_0_30px_rgba(182,255,0,0.4)] transition-all cursor-pointer active:scale-[0.99]"
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
          <span>Add New Expense / செலவு சேர்க்க</span>
        </button>

        {/* Animated Spending Rings (Daily, Weekly, Monthly) */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-white">Cash Flow & Pace</h3>
              <p className="text-[11px] text-[#888888]">Spent vs allowable targets</p>
            </div>
            <button
              onClick={() => navigate('AnalyticsPage')}
              className="text-xs text-[#00F5FF] hover:underline flex items-center gap-0.5 cursor-pointer font-medium"
            >
              <span>Full Analytics</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <SpendingRing
              label="Today"
              amountPaise={periodTotals.dailyPaise}
              limitPaise={dailyTargetPaise}
              color="#B6FF00"
              currencySymbol={profile.currencySymbol}
              onClick={() => {
                setSelectedRingPeriod('daily');
                navigate('HistoryPage');
              }}
            />
            <SpendingRing
              label="This Week"
              amountPaise={periodTotals.weeklyPaise}
              limitPaise={weeklyTargetPaise}
              color="#00F5FF"
              currencySymbol={profile.currencySymbol}
              onClick={() => {
                setSelectedRingPeriod('weekly');
                navigate('HistoryPage');
              }}
            />
            <SpendingRing
              label="This Month"
              amountPaise={periodTotals.monthlyPaise}
              limitPaise={monthlyTargetPaise}
              color="#FF2D78"
              currencySymbol={profile.currencySymbol}
              onClick={() => {
                setSelectedRingPeriod('monthly');
                navigate('CategoryAnalyticsPage');
              }}
            />
          </div>
        </div>

        {/* Recent Transactions Section */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Recent Transactions</h3>
              <p className="text-[11px] text-[#888888]">Latest recorded expenses</p>
            </div>
            <button
              onClick={() => navigate('HistoryPage')}
              className="text-xs text-[#B6FF00] hover:underline flex items-center gap-0.5 cursor-pointer font-medium"
            >
              <span>See All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentTransactions.length === 0 ? (
            <EmptyState
              title="No expenses yet"
              description="Start tracking by adding your first daily expense."
              actionText="Add Expense"
              onAction={() => navigate('AddExpensePage')}
            />
          ) : (
            <div className="space-y-2">
              {recentTransactions.map((exp) => (
                <TransactionListItem
                  key={exp.id}
                  expense={exp}
                  currencySymbol={profile.currencySymbol}
                  onClick={() => navigate('ExpenseDetailsPage', { expenseId: exp.id })}
                />
              ))}
            </div>
          )}
        </div>

        {/* Quick Budget Glance */}
        {budgets.length > 0 && (
          <div className="p-4 rounded-xl bg-[#121216] border border-[#27272A] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#00F5FF]/15 text-[#00F5FF] flex items-center justify-center">
                <Wallet className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">Active Budgets</h4>
                <p className="text-xs text-[#888888]">{budgets.length} budgets tracked</p>
              </div>
            </div>
            <button
              onClick={() => navigate('BudgetsPage')}
              className="py-1.5 px-3 rounded-lg bg-[#1A1A22] border border-[#27272A] text-xs font-semibold text-[#00F5FF] hover:border-[#00F5FF]/50 cursor-pointer transition-colors"
            >
              Manage →
            </button>
          </div>
        )}

        <DeveloperFooter />
      </main>

      {/* Persistent Bottom Navigation */}
      <BottomNavigation currentPage="HomePage" onNavigate={(page) => navigate(page)} />
    </div>
  );
};
