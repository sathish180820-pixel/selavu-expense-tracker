import React from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import { BottomNavigation } from '../components/BottomNavigation';
import {
  BudgetProgressCard,
  EmptyState,
  NeonPrimaryButton,
} from '../components/UIComponents';
import { Plus, Wallet, AlertCircle } from 'lucide-react';
import { getCategoryTotals, calculatePeriodTotals } from '../utils/finance';

export const BudgetsPage: React.FC = () => {
  const { profile, budgets, expenses, navigate } = useApp();

  const categoryTotals = getCategoryTotals(expenses);
  const periodTotals = calculatePeriodTotals(expenses);

  return (
    <div
      className="relative min-h-full w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="budgets-page"
    >
      <AppHeader
        title="Budgets & Limits"
        tamilSubtitle="பட்ஜெட்"
        showBack={true}
        onBack={() => navigate('HomePage')}
        rightAction={
          <button
            onClick={() => navigate('AddBudgetPage')}
            aria-label="Add budget"
            className="w-9 h-9 rounded-xl bg-[#00F5FF] text-black font-bold flex items-center justify-center hover:bg-[#3bf7ff] cursor-pointer transition-colors"
          >
            <Plus className="w-5 h-5 stroke-[2.5]" />
          </button>
        }
      />

      <main className="max-w-md mx-auto w-full px-4 pt-3 flex-1 space-y-4">
        {/* Intro Banner */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-[#121216] to-[#1A1A22] border border-[#27272A] flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white">Monthly Budgets</h3>
            <p className="text-xs text-[#888888] mt-0.5">
              Keep category spending below your allocated ceilings
            </p>
          </div>
          <button
            onClick={() => navigate('AddBudgetPage')}
            className="py-1.5 px-3 rounded-xl bg-[#B6FF00] text-black text-xs font-semibold hover:bg-[#c4ff2e] cursor-pointer flex items-center gap-1 shadow-[0_0_10px_rgba(182,255,0,0.25)]"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add</span>
          </button>
        </div>

        {/* Budgets List */}
        {budgets.length === 0 ? (
          <EmptyState
            icon={<Wallet className="w-7 h-7 text-[#00F5FF]" />}
            title="No budgets created"
            description="Create monthly ceilings for categories like Food, Transport, and Entertainment to stay on target."
            actionText="Create First Budget"
            onAction={() => navigate('AddBudgetPage')}
          />
        ) : (
          <div className="space-y-3">
            {budgets.map((b) => {
              const spentPaise =
                b.category === 'Overall'
                  ? periodTotals.monthlyPaise
                  : categoryTotals[b.category as keyof typeof categoryTotals] || 0;

              return (
                <BudgetProgressCard
                  key={b.id}
                  budget={b}
                  spentPaise={spentPaise}
                  currencySymbol={profile.currencySymbol}
                  onClick={() => navigate('BudgetDetailsPage', { budgetId: b.id })}
                />
              );
            })}
          </div>
        )}

        <DeveloperFooter />
      </main>

      <BottomNavigation currentPage="BudgetsPage" onNavigate={(p) => navigate(p)} />
    </div>
  );
};
