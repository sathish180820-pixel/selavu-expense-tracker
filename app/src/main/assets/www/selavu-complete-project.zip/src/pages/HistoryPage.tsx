import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import { BottomNavigation } from '../components/BottomNavigation';
import {
  TransactionListItem,
  EmptyState,
  CATEGORY_CONFIG,
} from '../components/UIComponents';
import { Search, Filter, X, Plus, Calendar, ArrowUpDown } from 'lucide-react';
import { ExpenseCategory, PaymentMethod } from '../types';
import { formatPaise } from '../utils/finance';

export const HistoryPage: React.FC = () => {
  const { profile, expenses, navigate } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ExpenseCategory | 'All'>('All');
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod | 'All'>('All');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  // Filtered and sorted transactions
  const filteredExpenses = useMemo(() => {
    return expenses
      .filter((exp) => {
        // Search matches merchant, category, or notes
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchMerchant = exp.merchant.toLowerCase().includes(q);
          const matchCat = exp.category.toLowerCase().includes(q);
          const matchNotes = (exp.notes || '').toLowerCase().includes(q);
          if (!matchMerchant && !matchCat && !matchNotes) return false;
        }

        // Category filter
        if (selectedCategory !== 'All' && exp.category !== selectedCategory) {
          return false;
        }

        // Payment method filter
        if (selectedPayment !== 'All' && exp.paymentMethod !== selectedPayment) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        const dateA = new Date(`${a.date}T${a.time || '00:00'}`).getTime();
        const dateB = new Date(`${b.date}T${b.time || '00:00'}`).getTime();
        return sortOrder === 'desc' ? dateB - dateA : dateA - dateB;
      });
  }, [expenses, searchQuery, selectedCategory, selectedPayment, sortOrder]);

  const totalFilteredPaise = useMemo(() => {
    return filteredExpenses.reduce((sum, item) => sum + item.amountPaise, 0);
  }, [filteredExpenses]);

  const categories: (ExpenseCategory | 'All')[] = [
    'All',
    'Food & Dining',
    'Transport',
    'Groceries',
    'Bills & Utilities',
    'Shopping',
    'Entertainment',
    'Health',
    'Education',
    'Travel',
    'Others',
  ];

  return (
    <div
      className="relative min-h-full w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="history-page"
    >
      <AppHeader
        title="Transaction History"
        tamilSubtitle="வரலாறு"
        showBack={true}
        onBack={() => navigate('HomePage')}
        rightAction={
          <button
            onClick={() => navigate('AddExpensePage')}
            aria-label="Add expense"
            className="w-9 h-9 rounded-xl bg-[#B6FF00] text-black font-bold flex items-center justify-center hover:bg-[#c4ff2e] cursor-pointer transition-colors"
          >
            <Plus className="w-5 h-5 stroke-[2.5]" />
          </button>
        }
      />

      <main className="max-w-md mx-auto w-full px-4 pt-3 flex-1 space-y-4">
        {/* Search Bar */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#888888]">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search merchants, categories, or notes..."
            className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-9 py-2.5 text-xs text-white placeholder-[#555] outline-none transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#888888] hover:text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Chips Horizontal Scroller */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`text-xs py-1.5 px-3 rounded-full border transition-all cursor-pointer shrink-0 ${
                selectedCategory === cat
                  ? 'bg-[#B6FF00] text-black font-semibold border-[#B6FF00]'
                  : 'bg-[#121216] text-[#A1A1AA] border-[#27272A] hover:border-[#555]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Totals & Sort Bar */}
        <div className="flex items-center justify-between py-1 text-xs text-[#888888]">
          <span>
            Found <strong className="text-white">{filteredExpenses.length}</strong> items (
            <strong className="text-[#FF5F1F] font-amount">
              {formatPaise(totalFilteredPaise, profile.currencySymbol)}
            </strong>
            )
          </span>

          <button
            onClick={() => setSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'))}
            className="flex items-center gap-1 text-[#A1A1AA] hover:text-[#B6FF00] cursor-pointer"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            <span>{sortOrder === 'desc' ? 'Newest first' : 'Oldest first'}</span>
          </button>
        </div>

        {/* List of Transactions */}
        {filteredExpenses.length === 0 ? (
          <EmptyState
            title="No transactions match"
            description={
              searchQuery || selectedCategory !== 'All'
                ? 'Try clearing your filters or search terms.'
                : 'No expenses have been recorded yet.'
            }
            actionText={
              searchQuery || selectedCategory !== 'All' ? 'Reset Filters' : 'Add First Expense'
            }
            onAction={() => {
              if (searchQuery || selectedCategory !== 'All') {
                setSearchQuery('');
                setSelectedCategory('All');
                setSelectedPayment('All');
              } else {
                navigate('AddExpensePage');
              }
            }}
          />
        ) : (
          <div className="space-y-2">
            {filteredExpenses.map((expense) => (
              <TransactionListItem
                key={expense.id}
                expense={expense}
                currencySymbol={profile.currencySymbol}
                onClick={() =>
                  navigate('ExpenseDetailsPage', { expenseId: expense.id, fromPage: 'HistoryPage' })
                }
              />
            ))}
          </div>
        )}

        <DeveloperFooter />
      </main>

      <BottomNavigation currentPage="HistoryPage" onNavigate={(p) => navigate(p)} />
    </div>
  );
};
