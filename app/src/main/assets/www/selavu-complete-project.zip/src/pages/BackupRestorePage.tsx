import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import {
  NeonPrimaryButton,
  NeonSecondaryButton,
  ErrorMessage,
} from '../components/UIComponents';
import { Database, Download, Upload, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';

export const BackupRestorePage: React.FC = () => {
  const { profile, expenses, budgets, settings, exportBackup, importBackup, navigate } = useApp();
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [restoreConfirmText, setRestoreConfirmText] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleCreateBackup = () => {
    try {
      const backupJson = exportBackup();
      const blob = new Blob([backupJson], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      a.href = url;
      a.download = `selavu_backup_${timestamp}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setStatusMessage({
        text: 'Backup file successfully created and downloaded to your device!',
        type: 'success',
      });
    } catch (e: unknown) {
      setStatusMessage({
        text: e instanceof Error ? e.message : 'Failed to generate backup file',
        type: 'error',
      });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setRestoreConfirmText(content);
    };
    reader.onerror = () => {
      setStatusMessage({ text: 'Failed to read selected file', type: 'error' });
    };
    reader.readAsText(file);
  };

  const handleConfirmRestore = () => {
    if (!restoreConfirmText) return;

    const result = importBackup(restoreConfirmText);
    if (result.success) {
      setRestoreConfirmText(null);
      setStatusMessage({
        text: 'All expenses, budgets, and profile restored successfully!',
        type: 'success',
      });
    } else {
      setStatusMessage({
        text: result.error || 'Restore failed due to invalid file format',
        type: 'error',
      });
    }
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="backup-restore-page"
    >
      <AppHeader
        title="Backup & Restore"
        tamilSubtitle="காப்புநகல்"
        showBack={true}
        onBack={() => navigate('SettingsPage')}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {statusMessage && (
          <div
            className={`p-4 rounded-xl border flex items-start gap-2.5 text-xs ${
              statusMessage.type === 'success'
                ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-400'
                : 'bg-rose-950/30 border-rose-500/40 text-rose-400'
            }`}
          >
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            ) : (
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            )}
            <span>{statusMessage.text}</span>
          </div>
        )}

        {/* Database Stats Card */}
        <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-5 space-y-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#00F5FF]/15 text-[#00F5FF] flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Local Storage Database</h3>
              <p className="text-xs text-[#888888]">Stored securely inside your browser & device</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#27272A] text-xs">
            <div className="bg-[#0B0B0F] p-2.5 rounded-xl border border-[#27272A]/70">
              <span className="text-[#888888] block text-[10px] uppercase">Recorded Expenses</span>
              <span className="text-base font-bold font-amount text-white">{expenses.length}</span>
            </div>
            <div className="bg-[#0B0B0F] p-2.5 rounded-xl border border-[#27272A]/70">
              <span className="text-[#888888] block text-[10px] uppercase">Active Budgets</span>
              <span className="text-base font-bold font-amount text-[#00F5FF]">{budgets.length}</span>
            </div>
          </div>

          {settings.lastBackupDate && (
            <p className="text-[11px] text-[#A1A1AA]">
              Last Backup: {new Date(settings.lastBackupDate).toLocaleString()}
            </p>
          )}
        </div>

        {/* Create Backup Action Card */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-5 space-y-3">
          <div>
            <h4 className="text-sm font-semibold text-white">Create Local Backup</h4>
            <p className="text-xs text-[#888888] mt-0.5 leading-relaxed">
              Export an encrypted JSON file containing all your records, settings, and profile details for safekeeping or transfer.
            </p>
          </div>

          <NeonPrimaryButton
            onClick={handleCreateBackup}
            icon={<Download className="w-4 h-4" />}
            data-testid="create-backup-button"
          >
            Create & Download Backup
          </NeonPrimaryButton>
        </div>

        {/* Restore Backup Action Card */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-5 space-y-3">
          <div>
            <h4 className="text-sm font-semibold text-white">Restore from Backup</h4>
            <p className="text-xs text-[#888888] mt-0.5 leading-relaxed">
              Select a previously saved `.json` file to restore your entire financial ledger.
            </p>
          </div>

          <input
            type="file"
            accept=".json,application/json"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="hidden"
          />

          <NeonSecondaryButton
            onClick={() => fileInputRef.current?.click()}
            icon={<Upload className="w-4 h-4 text-[#00F5FF]" />}
            data-testid="select-backup-file-button"
          >
            Select Backup JSON File
          </NeonSecondaryButton>

          {restoreConfirmText && (
            <div className="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/40 space-y-2 mt-2">
              <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Confirm Restore: This will replace current records with the file data.</span>
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  onClick={handleConfirmRestore}
                  className="flex-1 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-semibold text-xs cursor-pointer"
                >
                  Yes, Restore Now
                </button>
                <button
                  onClick={() => setRestoreConfirmText(null)}
                  className="flex-1 py-2 rounded-lg bg-[#121216] border border-[#27272A] text-[#CCC] text-xs cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>

        <DeveloperFooter />
      </main>
    </div>
  );
};
