import React from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import {
  Coins,
  Database,
  FileSpreadsheet,
  Info,
  ChevronRight,
  Bell,
  Fingerprint,
  Volume2,
  RefreshCw,
  Trash2,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { profile, settings, updateSettings, seedSampleData, resetAllData, navigate, goBack } = useApp();

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="settings-page"
    >
      <AppHeader
        title="Settings"
        tamilSubtitle="அமைப்புகள்"
        showBack={true}
        onBack={() => navigate('ProfilePage')}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {/* Preferences Section */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#888888] px-1">
            General & Currency
          </h3>

          {/* Currency setting shortcut */}
          <div
            onClick={() => navigate('CurrencySettingsPage')}
            role="button"
            tabIndex={0}
            className="flex items-center justify-between p-3.5 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#B6FF00]/40 transition-all cursor-pointer group"
            data-testid="currency-setting-item"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#B6FF00]/15 text-[#B6FF00] flex items-center justify-center font-bold font-amount">
                {profile.currencySymbol}
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white group-hover:text-[#B6FF00] transition-colors">
                  Currency / நாணயம்
                </h4>
                <p className="text-xs text-[#888888]">
                  Current: {profile.currencyCode} ({profile.currencySymbol})
                </p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#888888]" />
          </div>

          {/* Sound Effects Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#121216] border border-[#27272A]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#00F5FF]/15 text-[#00F5FF] flex items-center justify-center">
                <Volume2 className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">Audio Feedback</h4>
                <p className="text-xs text-[#888888]">Haptic & transaction chimes</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.soundEffects}
              onChange={(e) => updateSettings({ soundEffects: e.target.checked })}
              className="w-5 h-5 accent-[#B6FF00] rounded cursor-pointer"
            />
          </div>

          {/* Notifications Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#121216] border border-[#27272A]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#FF2D78]/15 text-[#FF2D78] flex items-center justify-center">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">Daily Spending Reminders</h4>
                <p className="text-xs text-[#888888]">Log daily tea & groceries notice</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.notificationsEnabled}
              onChange={(e) => updateSettings({ notificationsEnabled: e.target.checked })}
              className="w-5 h-5 accent-[#B6FF00] rounded cursor-pointer"
            />
          </div>

          {/* Biometric Lock Toggle */}
          <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#121216] border border-[#27272A]">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#39FF14]/15 text-[#39FF14] flex items-center justify-center">
                <Fingerprint className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">App Fingerprint Lock</h4>
                <p className="text-xs text-[#888888]">Secure offline database on app open</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.biometricLock}
              onChange={(e) => updateSettings({ biometricLock: e.target.checked })}
              className="w-5 h-5 accent-[#B6FF00] rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Data & Integrations Section */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#888888] px-1">
            Data Management
          </h3>

          {/* Backup shortcut */}
          <div
            onClick={() => navigate('BackupRestorePage')}
            role="button"
            tabIndex={0}
            className="flex items-center justify-between p-3.5 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#00F5FF]/40 transition-all cursor-pointer group"
            data-testid="backup-shortcut-item"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#00F5FF]/15 text-[#00F5FF] flex items-center justify-center">
                <Database className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white group-hover:text-[#00F5FF] transition-colors">
                  Backup & Restore
                </h4>
                <p className="text-xs text-[#888888]">Export offline snapshot or restore files</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#888888]" />
          </div>

          {/* Export shortcut */}
          <div
            onClick={() => navigate('ExportDataPage')}
            role="button"
            tabIndex={0}
            className="flex items-center justify-between p-3.5 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#FF2D78]/40 transition-all cursor-pointer group"
            data-testid="export-shortcut-item"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#FF2D78]/15 text-[#FF2D78] flex items-center justify-center">
                <FileSpreadsheet className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white group-hover:text-[#FF2D78] transition-colors">
                  Export Data (CSV)
                </h4>
                <p className="text-xs text-[#888888]">Download complete spreadsheet</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#888888]" />
          </div>

          {/* About shortcut */}
          <div
            onClick={() => navigate('AboutPage')}
            role="button"
            tabIndex={0}
            className="flex items-center justify-between p-3.5 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#A1A1AA] transition-all cursor-pointer group"
            data-testid="about-shortcut-item"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-[#A1A1AA]/15 text-[#A1A1AA] flex items-center justify-center">
                <Info className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white group-hover:text-[#B6FF00] transition-colors">
                  About Selavu (செலவு)
                </h4>
                <p className="text-xs text-[#888888]">App specs, credits & legal</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#888888]" />
          </div>
        </div>

        {/* Reset & Demo Utilities */}
        <div className="pt-2 space-y-2">
          <button
            onClick={() => {
              seedSampleData();
              alert('Sample Indian expense records reloaded successfully!');
            }}
            className="w-full py-3 px-4 rounded-xl bg-[#121216] hover:bg-[#1A1A22] border border-[#27272A] text-xs font-medium text-[#A1A1AA] hover:text-[#B6FF00] flex items-center justify-center gap-2 cursor-pointer transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reload Sample Demo Transactions</span>
          </button>
        </div>

        <DeveloperFooter />
      </main>
    </div>
  );
};
