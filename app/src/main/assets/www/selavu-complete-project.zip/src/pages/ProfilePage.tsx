import React from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import { BottomNavigation } from '../components/BottomNavigation';
import {
  Edit3,
  Settings,
  Database,
  FileSpreadsheet,
  Info,
  ChevronRight,
  ShieldCheck,
  User,
  Wallet,
  PiggyBank,
} from 'lucide-react';
import { formatPaise } from '../utils/finance';

export const ProfilePage: React.FC = () => {
  const { profile, navigate } = useApp();

  return (
    <div
      className="relative min-h-full w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="profile-page"
    >
      <AppHeader
        title="My Profile"
        tamilSubtitle="சுயவிவரம்"
        showBack={true}
        onBack={() => navigate('HomePage')}
        rightAction={
          /* Profile pencil IconButton connected to EditProfilePage */
          <button
            onClick={() => navigate('EditProfilePage')}
            aria-label="Edit Profile"
            className="w-9 h-9 rounded-xl bg-[#121216] border border-[#27272A] text-[#B6FF00] hover:bg-[#1A1A22] flex items-center justify-center cursor-pointer transition-colors"
            data-testid="profile-pencil-button"
          >
            <Edit3 className="w-4 h-4" />
          </button>
        }
      />

      <main className="max-w-md mx-auto w-full px-4 pt-3 flex-1 space-y-5">
        {/* Profile Card Header */}
        <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-5 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#B6FF00]/20 to-[#00F5FF]/20 border border-[#B6FF00]/50 flex items-center justify-center text-xl font-extrabold font-amount text-[#B6FF00] shadow-[0_0_15px_rgba(182,255,0,0.2)]">
              {profile.name ? profile.name.charAt(0).toUpperCase() : 'S'}
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">{profile.name}</h2>
              <p className="text-xs text-[#888888]">{profile.email || 'Offline Local Account'}</p>
              <span className="inline-flex items-center gap-1 mt-1 text-[10px] font-semibold text-[#B6FF00] bg-[#B6FF00]/10 px-2 py-0.5 rounded-full">
                <ShieldCheck className="w-3 h-3" />
                Local Storage Active
              </span>
            </div>
          </div>

          <button
            onClick={() => navigate('EditProfilePage')}
            className="p-2 rounded-xl bg-[#0B0B0F] border border-[#27272A] text-[#A1A1AA] hover:text-[#B6FF00] cursor-pointer transition-colors"
          >
            <Edit3 className="w-4 h-4" />
          </button>
        </div>

        {/* Financial Profile Card */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-4 rounded-xl bg-[#121216] border border-[#27272A]">
            <div className="flex items-center gap-2 text-xs text-[#888888] mb-1">
              <Wallet className="w-3.5 h-3.5 text-[#00F5FF]" />
              <span>Monthly Salary</span>
            </div>
            <p className="text-base font-bold font-amount text-white">
              {formatPaise(profile.monthlySalaryPaise, profile.currencySymbol)}
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#121216] border border-[#27272A]">
            <div className="flex items-center gap-2 text-xs text-[#888888] mb-1">
              <PiggyBank className="w-3.5 h-3.5 text-[#B6FF00]" />
              <span>Savings Target</span>
            </div>
            <p className="text-base font-bold font-amount text-[#B6FF00]">
              {formatPaise(profile.savingsGoalPaise, profile.currencySymbol)}
            </p>
          </div>
        </div>

        {/* Menu Cards (Settings, Backup & Restore, Export Data, About) */}
        <div className="space-y-2">
          {/* Settings Container / Card */}
          <div
            onClick={() => navigate('SettingsPage')}
            role="button"
            tabIndex={0}
            className="flex items-center justify-between p-4 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#B6FF00]/40 transition-all cursor-pointer group"
            data-testid="settings-card-button"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#B6FF00]/15 text-[#B6FF00] flex items-center justify-center">
                <Settings className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white group-hover:text-[#B6FF00] transition-colors">
                  Settings / அமைப்புகள்
                </h4>
                <p className="text-xs text-[#888888]">Currency, reminders, and preferences</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#888888]" />
          </div>

          {/* Backup & Restore card */}
          <div
            onClick={() => navigate('BackupRestorePage')}
            role="button"
            tabIndex={0}
            className="flex items-center justify-between p-4 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#00F5FF]/40 transition-all cursor-pointer group"
            data-testid="backup-restore-card-button"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#00F5FF]/15 text-[#00F5FF] flex items-center justify-center">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white group-hover:text-[#00F5FF] transition-colors">
                  Backup & Restore / காப்புநகல்
                </h4>
                <p className="text-xs text-[#888888]">Save JSON snapshot or restore previous data</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#888888]" />
          </div>

          {/* Export Data card */}
          <div
            onClick={() => navigate('ExportDataPage')}
            role="button"
            tabIndex={0}
            className="flex items-center justify-between p-4 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#FF2D78]/40 transition-all cursor-pointer group"
            data-testid="export-data-card-button"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#FF2D78]/15 text-[#FF2D78] flex items-center justify-center">
                <FileSpreadsheet className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white group-hover:text-[#FF2D78] transition-colors">
                  Export Data (CSV) / ஏற்றுமதி
                </h4>
                <p className="text-xs text-[#888888]">Download Excel/Sheets compatible spreadsheet</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#888888]" />
          </div>

          {/* About card */}
          <div
            onClick={() => navigate('AboutPage')}
            role="button"
            tabIndex={0}
            className="flex items-center justify-between p-4 rounded-xl bg-[#121216] border border-[#27272A] hover:border-[#A1A1AA] transition-all cursor-pointer group"
            data-testid="about-card-button"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-[#A1A1AA]/15 text-[#A1A1AA] flex items-center justify-center">
                <Info className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white group-hover:text-[#B6FF00] transition-colors">
                  About Selavu / பற்றி
                </h4>
                <p className="text-xs text-[#888888]">Version 1.0 • Developed by மூ சதீஷ்</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-[#888888]" />
          </div>
        </div>

        <DeveloperFooter />
      </main>

      <BottomNavigation currentPage="ProfilePage" onNavigate={(p) => navigate(p)} />
    </div>
  );
};
