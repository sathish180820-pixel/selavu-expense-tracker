import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import {
  NeonPrimaryButton,
  NeonSecondaryButton,
  CATEGORY_CONFIG,
  PAYMENT_METHOD_ICONS,
  ErrorMessage,
} from '../components/UIComponents';
import { ExpenseCategory, PaymentMethod } from '../types';
import { rupeesToPaise } from '../utils/finance';
import { Check, Calendar, Clock, FileText, Store } from 'lucide-react';

const CATEGORIES: ExpenseCategory[] = [
  'Food & Dining',
  'Transport',
  'Groceries',
  'Bills & Utilities',
  'Shopping',
  'Entertainment',
  'Health',
  'Education',
  'Travel',
  'Others',
];

const PAYMENT_METHODS: PaymentMethod[] = [
  'UPI',
  'Cash',
  'Credit Card',
  'Debit Card',
  'Net Banking',
];

export const AddExpensePage: React.FC = () => {
  const { profile, addExpense, navigate, goBack } = useApp();

  const now = new Date();
  const todayStr = now.toISOString().split('T')[0];
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  const [amountStr, setAmountStr] = useState<string>('');
  const [merchant, setMerchant] = useState<string>('');
  const [category, setCategory] = useState<ExpenseCategory>('Food & Dining');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [date, setDate] = useState<string>(todayStr);
  const [time, setTime] = useState<string>(timeStr);
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  const handleQuickAdd = (value: number) => {
    const current = parseFloat(amountStr) || 0;
    setAmountStr((current + value).toString());
  };

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const amt = parseFloat(amountStr);
    if (isNaN(amt) || amt <= 0) {
      setError('Please enter a valid expense amount greater than 0');
      return;
    }
    if (!merchant.trim()) {
      setError('Please specify a merchant or recipient name');
      return;
    }
    if (!date) {
      setError('Please select a valid date');
      return;
    }

    try {
      const createdExpense = addExpense({
        amountPaise: rupeesToPaise(amt),
        category,
        merchant: merchant.trim(),
        paymentMethod,
        date,
        time: time || '12:00',
        notes: notes.trim(),
      });

      // Navigate to ExpenseSavedPage with created expense id
      navigate('ExpenseSavedPage', { savedExpenseId: createdExpense.id });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to save expense');
    }
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="add-expense-page"
    >
      <AppHeader
        title="Add Expense"
        tamilSubtitle="செலவு சேர்க்க"
        showBack={true}
        onBack={goBack}
        closeIcon={true}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSave} className="space-y-5">
          {/* Amount Input */}
          <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-4 text-center">
            <label className="text-xs font-semibold uppercase tracking-wider text-[#A1A1AA] block mb-1">
              Expense Amount
            </label>
            <div className="flex items-center justify-center gap-1 my-2">
              <span className="text-3xl font-extrabold text-[#B6FF00] font-amount">
                {profile.currencySymbol}
              </span>
              <input
                type="number"
                step="any"
                min="0.5"
                placeholder="0"
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                autoFocus
                className="w-48 bg-transparent text-4xl sm:text-5xl font-extrabold font-amount text-white text-center outline-none placeholder-[#333]"
                required
              />
            </div>

            {/* Quick Amount Chips */}
            <div className="flex items-center justify-center gap-2 mt-3 flex-wrap">
              {[50, 100, 200, 500, 1000].map((quick) => (
                <button
                  key={quick}
                  type="button"
                  onClick={() => handleQuickAdd(quick)}
                  className="py-1 px-2.5 rounded-lg bg-[#0B0B0F] hover:bg-[#1A1A22] border border-[#27272A] hover:border-[#B6FF00]/50 text-xs text-[#A1A1AA] hover:text-[#B6FF00] font-amount transition-colors cursor-pointer"
                >
                  +{profile.currencySymbol}{quick}
                </button>
              ))}
            </div>
          </div>

          {/* Merchant Input */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
              Merchant / Spent At / கடை பெயர்
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#888888]">
                <Store className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={merchant}
                onChange={(e) => setMerchant(e.target.value)}
                placeholder="e.g. Swiggy, Saravana Bhavan, Uber"
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-[#555] outline-none transition-all"
                required
              />
            </div>
          </div>

          {/* Category Selection Grid */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-2">
              Select Category / வகை
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {CATEGORIES.map((cat) => {
                const config = CATEGORY_CONFIG[cat];
                const Icon = config.icon;
                const isSelected = category === cat;

                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#1A1A22] border-[#B6FF00] shadow-[0_0_10px_rgba(182,255,0,0.2)]'
                        : 'bg-[#121216] border-[#27272A] hover:border-[#444]'
                    }`}
                  >
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                      style={{ backgroundColor: config.bg, color: config.color }}
                    >
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span
                      className={`text-xs font-semibold truncate ${
                        isSelected ? 'text-[#B6FF00]' : 'text-[#CCC]'
                      }`}
                    >
                      {cat}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Payment Method Chips */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-2">
              Payment Method / செலுத்தும் முறை
            </label>
            <div className="flex flex-wrap gap-2">
              {PAYMENT_METHODS.map((pm) => {
                const Icon = PAYMENT_METHOD_ICONS[pm];
                const isSelected = paymentMethod === pm;

                return (
                  <button
                    key={pm}
                    type="button"
                    onClick={() => setPaymentMethod(pm)}
                    className={`flex items-center gap-1.5 py-2 px-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#00F5FF]/15 text-[#00F5FF] border-[#00F5FF] shadow-[0_0_8px_rgba(0,245,255,0.25)]'
                        : 'bg-[#121216] text-[#A1A1AA] border-[#27272A] hover:border-[#444]'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{pm}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date and Time Row */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
                Date / தேதி
              </label>
              <div className="relative">
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl px-3 py-2.5 text-xs text-white outline-none"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
                Time / நேரம்
              </label>
              <div className="relative">
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl px-3 py-2.5 text-xs text-white outline-none"
                />
              </div>
            </div>
          </div>

          {/* Notes Input */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
              Notes (Optional) / குறிப்புகள்
            </label>
            <div className="relative">
              <div className="absolute top-3 left-3.5 text-[#888888] pointer-events-none">
                <FileText className="w-4 h-4" />
              </div>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add any context, bill number, or tags..."
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-[#555] outline-none transition-all resize-none"
              />
            </div>
          </div>

          {/* Action Buttons: Save & Cancel */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <NeonPrimaryButton
              type="submit"
              icon={<Check className="w-4 h-4" />}
              data-testid="save-expense-button"
            >
              Save Expense / சேமிக்கவும்
            </NeonPrimaryButton>

            <NeonSecondaryButton
              type="button"
              onClick={goBack}
              data-testid="cancel-expense-button"
            >
              Cancel
            </NeonSecondaryButton>
          </div>
        </form>

        <DeveloperFooter />
      </main>
    </div>
  );
};
