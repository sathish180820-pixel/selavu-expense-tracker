import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import {
  NeonPrimaryButton,
  NeonSecondaryButton,
  CATEGORY_CONFIG,
  PAYMENT_METHOD_ICONS,
  EmptyState,
} from '../components/UIComponents';
import {
  Edit3,
  Trash2,
  Calendar,
  Clock,
  CreditCard,
  Tag,
  Store,
  FileText,
  AlertTriangle,
  ArrowLeft,
} from 'lucide-react';
import { formatPaise } from '../utils/finance';

export const ExpenseDetailsPage: React.FC = () => {
  const { profile, expenses, navigation, deleteExpense, navigate, goBack } = useApp();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const expenseId = navigation.params?.expenseId;
  const expense = expenses.find((e) => e.id === expenseId);

  if (!expense) {
    return (
      <div
        className="min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
        data-testid="expense-details-page"
      >
        <AppHeader title="Transaction Not Found" showBack={true} onBack={goBack} />
        <main className="max-w-md mx-auto w-full px-4 py-8 flex-1">
          <EmptyState
            title="Expense not found"
            description="The selected transaction might have been deleted or is unavailable."
            actionText="Go to History"
            onAction={() => navigate('HistoryPage')}
          />
        </main>
        <DeveloperFooter />
      </div>
    );
  }

  const categoryConfig = CATEGORY_CONFIG[expense.category] || CATEGORY_CONFIG.Others;
  const CategoryIcon = categoryConfig.icon;
  const PaymentIcon = PAYMENT_METHOD_ICONS[expense.paymentMethod] || CreditCard;

  const handleDelete = () => {
    deleteExpense(expense.id);
    navigate('HistoryPage');
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="expense-details-page"
    >
      <AppHeader
        title="Expense Details"
        tamilSubtitle="விவரங்கள்"
        showBack={true}
        onBack={goBack}
        rightAction={
          <button
            onClick={() => navigate('EditExpensePage', { expenseId: expense.id })}
            aria-label="Edit expense"
            className="w-9 h-9 rounded-xl bg-[#121216] border border-[#27272A] text-[#B6FF00] hover:bg-[#1A1A22] flex items-center justify-center cursor-pointer transition-colors"
          >
            <Edit3 className="w-4 h-4" />
          </button>
        }
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {/* Main Amount Card */}
        <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-6 text-center relative overflow-hidden">
          <div
            className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center mb-3 shadow-lg"
            style={{ backgroundColor: categoryConfig.bg, color: categoryConfig.color }}
          >
            <CategoryIcon className="w-8 h-8" />
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold font-amount text-white tracking-tight">
            -{formatPaise(expense.amountPaise, profile.currencySymbol)}
          </h2>
          <p className="text-base font-semibold text-[#A1A1AA] mt-1">{expense.merchant}</p>
          <span
            className="inline-block mt-2 px-3 py-1 rounded-full text-xs font-semibold"
            style={{ backgroundColor: categoryConfig.bg, color: categoryConfig.color }}
          >
            {expense.category}
          </span>
        </div>

        {/* Detailed Breakdown Card */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-4 space-y-3.5">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#888888]">
            Transaction Properties
          </h3>

          <div className="flex items-center justify-between py-2 border-b border-[#27272A] text-xs">
            <span className="flex items-center gap-2 text-[#888888]">
              <Store className="w-4 h-4 text-[#A1A1AA]" />
              Merchant / Store
            </span>
            <span className="font-semibold text-white">{expense.merchant}</span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-[#27272A] text-xs">
            <span className="flex items-center gap-2 text-[#888888]">
              <PaymentIcon className="w-4 h-4 text-[#00F5FF]" />
              Payment Method
            </span>
            <span className="font-semibold text-[#00F5FF]">{expense.paymentMethod}</span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-[#27272A] text-xs">
            <span className="flex items-center gap-2 text-[#888888]">
              <Calendar className="w-4 h-4 text-[#A1A1AA]" />
              Date
            </span>
            <span className="font-semibold text-white">{expense.date}</span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-[#27272A] text-xs">
            <span className="flex items-center gap-2 text-[#888888]">
              <Clock className="w-4 h-4 text-[#A1A1AA]" />
              Time
            </span>
            <span className="font-semibold text-white">{expense.time}</span>
          </div>

          <div className="flex items-center justify-between py-2 text-xs">
            <span className="flex items-center gap-2 text-[#888888]">
              <Tag className="w-4 h-4 text-[#A1A1AA]" />
              Record ID
            </span>
            <span className="font-mono text-[10px] text-[#A1A1AA]">{expense.id}</span>
          </div>
        </div>

        {/* Notes Card if present */}
        {expense.notes && (
          <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-4">
            <span className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#888888] mb-1.5">
              <FileText className="w-3.5 h-3.5" />
              Notes / குறிப்புகள்
            </span>
            <p className="text-xs text-[#DDD] leading-relaxed whitespace-pre-wrap">
              {expense.notes}
            </p>
          </div>
        )}

        {/* Action Buttons: Edit and Delete */}
        <div className="pt-2 space-y-3">
          <NeonPrimaryButton
            onClick={() => navigate('EditExpensePage', { expenseId: expense.id })}
            icon={<Edit3 className="w-4 h-4" />}
            data-testid="edit-expense-button"
          >
            Edit Expense / திருத்து
          </NeonPrimaryButton>

          {showDeleteConfirm ? (
            <div className="p-4 rounded-xl bg-red-950/30 border border-red-500/40 space-y-3">
              <div className="flex items-center gap-2 text-red-400 text-xs font-semibold">
                <AlertTriangle className="w-4 h-4" />
                <span>Are you sure you want to delete this expense?</span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleDelete}
                  className="flex-1 py-2 px-3 rounded-lg bg-red-600 hover:bg-red-500 text-white font-semibold text-xs cursor-pointer transition-colors"
                >
                  Yes, Delete
                </button>
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 py-2 px-3 rounded-lg bg-[#121216] border border-[#27272A] text-[#CCC] text-xs cursor-pointer hover:bg-[#1A1A22]"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <NeonSecondaryButton
              onClick={() => setShowDeleteConfirm(true)}
              icon={<Trash2 className="w-4 h-4 text-[#FF2D78]" />}
              data-testid="delete-expense-button"
            >
              <span className="text-[#FF2D78]">Delete Expense</span>
            </NeonSecondaryButton>
          )}
        </div>

        <DeveloperFooter />
      </main>
    </div>
  );
};
