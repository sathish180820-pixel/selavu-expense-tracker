import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import { BottomNavigation } from '../components/BottomNavigation';
import {
  CategoryCard,
  CATEGORY_CONFIG,
  PAYMENT_METHOD_ICONS,
} from '../components/UIComponents';
import {
  PieChart,
  BarChart3,
  Calendar,
  ArrowRight,
  TrendingUp,
  CreditCard,
} from 'lucide-react';
import { ExpenseCategory, PaymentMethod } from '../types';
import { formatPaise, getCategoryTotals, calculatePeriodTotals } from '../utils/finance';

export const AnalyticsPage: React.FC = () => {
  const { profile, expenses, navigate } = useApp();
  const [activePeriod, setActivePeriod] = useState<'this_month' | 'last_30_days' | 'all_time'>('this_month');

  // Filter expenses by period
  const filteredExpenses = useMemo(() => {
    const now = new Date();
    if (activePeriod === 'this_month') {
      const curYear = now.getFullYear();
      const curMonth = now.getMonth();
      return expenses.filter((e) => {
        const d = new Date(e.date + 'T00:00:00');
        return d.getFullYear() === curYear && d.getMonth() === curMonth;
      });
    } else if (activePeriod === 'last_30_days') {
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(now.getDate() - 30);
      return expenses.filter((e) => {
        const d = new Date(e.date + 'T00:00:00');
        return d >= thirtyDaysAgo;
      });
    }
    return expenses;
  }, [expenses, activePeriod]);

  const totalSpentPaise = useMemo(() => {
    return filteredExpenses.reduce((acc, e) => acc + e.amountPaise, 0);
  }, [filteredExpenses]);

  // Category aggregations
  const categoryMap = useMemo(() => {
    const map: Record<string, number> = {};
    for (const exp of filteredExpenses) {
      map[exp.category] = (map[exp.category] || 0) + exp.amountPaise;
    }
    return map;
  }, [filteredExpenses]);

  // Payment method aggregations
  const paymentMap = useMemo(() => {
    const map: Record<string, number> = {};
    for (const exp of filteredExpenses) {
      map[exp.paymentMethod] = (map[exp.paymentMethod] || 0) + exp.amountPaise;
    }
    return map;
  }, [filteredExpenses]);

  const sortedCategories = useMemo(() => {
    return Object.entries(categoryMap).sort((a, b) => b[1] - a[1]);
  }, [categoryMap]);

  return (
    <div
      className="relative min-h-full w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="analytics-page"
    >
      <AppHeader
        title="Spending Analytics"
        tamilSubtitle="பகுப்பாய்வு"
        showBack={true}
        onBack={() => navigate('HomePage')}
      />

      <main className="max-w-md mx-auto w-full px-4 pt-3 flex-1 space-y-5">
        {/* Period Selector Chips */}
        <div className="flex items-center gap-2 bg-[#121216] p-1.5 rounded-xl border border-[#27272A]">
          <button
            onClick={() => setActivePeriod('this_month')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              activePeriod === 'this_month'
                ? 'bg-[#B6FF00] text-black shadow-[0_0_8px_rgba(182,255,0,0.3)]'
                : 'text-[#A1A1AA] hover:text-white'
            }`}
          >
            This Month
          </button>
          <button
            onClick={() => setActivePeriod('last_30_days')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              activePeriod === 'last_30_days'
                ? 'bg-[#B6FF00] text-black shadow-[0_0_8px_rgba(182,255,0,0.3)]'
                : 'text-[#A1A1AA] hover:text-white'
            }`}
          >
            Last 30 Days
          </button>
          <button
            onClick={() => setActivePeriod('all_time')}
            className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
              activePeriod === 'all_time'
                ? 'bg-[#B6FF00] text-black shadow-[0_0_8px_rgba(182,255,0,0.3)]'
                : 'text-[#A1A1AA] hover:text-white'
            }`}
          >
            All Time
          </button>
        </div>

        {/* Total Spending in Period Card */}
        <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-5 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#B6FF00]/10 rounded-full blur-2xl pointer-events-none" />
          <span className="text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold">
            Total Outflow in Period
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold font-amount text-white tracking-tight mt-1">
            {formatPaise(totalSpentPaise, profile.currencySymbol)}
          </h2>
          <p className="text-xs text-[#888888] mt-1">
            Across {filteredExpenses.length} transactions
          </p>

          {/* Monthly Comparison banner shortcut */}
          <button
            onClick={() => navigate('MonthlyComparisonPage', { period: activePeriod })}
            className="mt-4 w-full py-2 px-3 rounded-xl bg-[#0B0B0F] hover:bg-[#1A1A22] border border-[#27272A] hover:border-[#00F5FF]/50 text-xs text-[#00F5FF] flex items-center justify-center gap-1.5 cursor-pointer transition-all"
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Open Monthly Comparison Chart →</span>
          </button>
        </div>

        {/* Category Breakdown Section */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Category Breakdown</h3>
              <p className="text-[11px] text-[#888888]">Tap a category to inspect transactions</p>
            </div>
            <span className="text-xs text-[#B6FF00] font-semibold">
              {sortedCategories.length} Categories
            </span>
          </div>

          {sortedCategories.length === 0 ? (
            <p className="text-xs text-[#888888] text-center py-4 bg-[#121216] rounded-xl border border-[#27272A]">
              No expenses in this period.
            </p>
          ) : (
            <div className="space-y-2">
              {sortedCategories.map(([catName, amt]) => {
                const percentage =
                  totalSpentPaise > 0 ? Math.round((amt / totalSpentPaise) * 100) : 0;

                return (
                  <CategoryCard
                    key={catName}
                    category={catName as ExpenseCategory}
                    amountPaise={amt}
                    percentage={percentage}
                    currencySymbol={profile.currencySymbol}
                    onClick={() =>
                      navigate('CategoryAnalyticsPage', {
                        category: catName as ExpenseCategory,
                        period: activePeriod,
                      })
                    }
                  />
                );
              })}
            </div>
          )}
        </div>

        {/* Payment Methods Distribution */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Payment Methods</h3>
            <span className="text-xs text-[#888888]">UPI vs Cash vs Cards</span>
          </div>

          <div className="space-y-2.5">
            {Object.entries(paymentMap).map(([pm, amt]) => {
              const Icon = PAYMENT_METHOD_ICONS[pm as PaymentMethod] || CreditCard;
              const pct = totalSpentPaise > 0 ? Math.round((amt / totalSpentPaise) * 100) : 0;

              return (
                <div key={pm} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 text-white font-medium">
                      <Icon className="w-3.5 h-3.5 text-[#00F5FF]" />
                      <span>{pm}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[#888888] font-amount">{pct}%</span>
                      <span className="font-bold font-amount text-white">
                        {formatPaise(amt, profile.currencySymbol)}
                      </span>
                    </div>
                  </div>
                  <div className="w-full bg-[#050505] rounded-full h-1.5 overflow-hidden">
                    <div
                      className="h-full bg-[#00F5FF] rounded-full"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <DeveloperFooter />
      </main>

      <BottomNavigation currentPage="AnalyticsPage" onNavigate={(p) => navigate(p)} />
    </div>
  );
};
