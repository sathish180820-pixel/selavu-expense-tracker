import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import {
  NeonPrimaryButton,
  NeonSecondaryButton,
  ErrorMessage,
} from '../components/UIComponents';
import { paiseToRupees, rupeesToPaise } from '../utils/finance';
import { Check, User, Mail, DollarSign, PiggyBank } from 'lucide-react';

export const EditProfilePage: React.FC = () => {
  const { profile, saveProfile, navigate } = useApp();

  const [name, setName] = useState(profile.name || '');
  const [email, setEmail] = useState(profile.email || '');
  const [salaryStr, setSalaryStr] = useState(
    profile.monthlySalaryPaise ? paiseToRupees(profile.monthlySalaryPaise).toString() : '75000'
  );
  const [goalStr, setGoalStr] = useState(
    profile.savingsGoalPaise ? paiseToRupees(profile.savingsGoalPaise).toString() : '25000'
  );
  const [error, setError] = useState<string | null>(null);

  const handleSaveChanges = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    if (!name.trim()) {
      setError('Name cannot be empty');
      return;
    }
    const salaryNum = parseFloat(salaryStr);
    if (isNaN(salaryNum) || salaryNum <= 0) {
      setError('Please enter a valid monthly salary');
      return;
    }
    const goalNum = parseFloat(goalStr);
    if (isNaN(goalNum) || goalNum < 0) {
      setError('Please enter a valid savings goal');
      return;
    }
    if (goalNum > salaryNum) {
      setError('Savings goal cannot exceed your monthly salary');
      return;
    }

    try {
      saveProfile({
        name: name.trim(),
        email: email.trim(),
        monthlySalaryPaise: rupeesToPaise(salaryNum),
        savingsGoalPaise: rupeesToPaise(goalNum),
      });

      navigate('ProfilePage');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to update profile');
    }
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="edit-profile-page"
    >
      <AppHeader
        title="Edit Profile"
        tamilSubtitle="சுயவிவரம் திருத்து"
        showBack={true}
        onBack={() => navigate('ProfilePage')}
        closeIcon={true}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSaveChanges} className="space-y-4">
          {/* Name Field */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
              Full Name / பெயர்
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#888888]">
                <User className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-4 py-3 text-sm text-white outline-none"
                required
              />
            </div>
          </div>

          {/* Email Field */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
              Email Address (Optional)
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#888888]">
                <Mail className="w-4 h-4" />
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="sathish@example.com"
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-4 py-3 text-sm text-white outline-none"
              />
            </div>
          </div>

          {/* Monthly Salary */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
              Monthly Salary ({profile.currencySymbol})
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#B6FF00] font-bold">
                ₹
              </div>
              <input
                type="number"
                min="1000"
                step="500"
                value={salaryStr}
                onChange={(e) => setSalaryStr(e.target.value)}
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-4 py-3 text-base font-amount text-white outline-none"
                required
              />
            </div>
          </div>

          {/* Monthly Savings Goal */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
              Monthly Savings Goal ({profile.currencySymbol})
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#00F5FF] font-bold">
                ₹
              </div>
              <input
                type="number"
                min="0"
                step="500"
                value={goalStr}
                onChange={(e) => setGoalStr(e.target.value)}
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-4 py-3 text-base font-amount text-white outline-none"
                required
              />
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-3 flex flex-col sm:flex-row gap-3">
            <NeonPrimaryButton
              type="submit"
              icon={<Check className="w-4 h-4" />}
              data-testid="save-profile-changes-button"
            >
              Save Changes / சேமி
            </NeonPrimaryButton>

            <NeonSecondaryButton
              type="button"
              onClick={() => navigate('ProfilePage')}
              data-testid="cancel-edit-profile-button"
            >
              Cancel
            </NeonSecondaryButton>
          </div>
        </form>

        <DeveloperFooter />
      </main>
    </div>
  );
};
