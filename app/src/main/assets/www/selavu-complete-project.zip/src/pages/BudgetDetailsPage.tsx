import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import {
  NeonPrimaryButton,
  NeonSecondaryButton,
  EmptyState,
  CATEGORY_CONFIG,
} from '../components/UIComponents';
import {
  Edit3,
  Trash2,
  Wallet,
  AlertTriangle,
  CheckCircle2,
  TrendingDown,
  Calendar,
} from 'lucide-react';
import { formatPaise, getCategoryTotals, calculatePeriodTotals } from '../utils/finance';

export const BudgetDetailsPage: React.FC = () => {
  const { profile, budgets, expenses, navigation, deleteBudget, navigate } = useApp();
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const budgetId = navigation.params?.budgetId;
  const budget = budgets.find((b) => b.id === budgetId);

  if (!budget) {
    return (
      <div
        className="min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
        data-testid="budget-details-page"
      >
        <AppHeader title="Budget Not Found" showBack={true} onBack={() => navigate('BudgetsPage')} />
        <main className="max-w-md mx-auto w-full px-4 py-8 flex-1">
          <EmptyState
            title="Budget not found"
            description="The selected budget is missing or has been deleted."
            actionText="Go to Budgets"
            onAction={() => navigate('BudgetsPage')}
          />
        </main>
        <DeveloperFooter />
      </div>
    );
  }

  const categoryTotals = getCategoryTotals(expenses);
  const periodTotals = calculatePeriodTotals(expenses);
  const spentPaise =
    budget.category === 'Overall'
      ? periodTotals.monthlyPaise
      : categoryTotals[budget.category as keyof typeof categoryTotals] || 0;

  const percent =
    budget.monthlyLimitPaise > 0
      ? Math.min(100, Math.round((spentPaise / budget.monthlyLimitPaise) * 100))
      : 0;
  const isOver = spentPaise > budget.monthlyLimitPaise;
  const remainingPaise = budget.monthlyLimitPaise - spentPaise;

  const handleDelete = () => {
    deleteBudget(budget.id);
    navigate('BudgetsPage');
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="budget-details-page"
    >
      <AppHeader
        title={`${budget.category} Budget`}
        tamilSubtitle="பட்ஜெட் விவரம்"
        showBack={true}
        onBack={() => navigate('BudgetsPage')}
        rightAction={
          <button
            onClick={() => navigate('EditBudgetPage', { budgetId: budget.id })}
            aria-label="Edit budget"
            className="w-9 h-9 rounded-xl bg-[#121216] border border-[#27272A] text-[#00F5FF] hover:bg-[#1A1A22] flex items-center justify-center cursor-pointer transition-colors"
          >
            <Edit3 className="w-4 h-4" />
          </button>
        }
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {/* Main Budget Card */}
        <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-6 text-center relative overflow-hidden">
          <div className="w-14 h-14 rounded-2xl bg-[#00F5FF]/15 border border-[#00F5FF]/30 text-[#00F5FF] mx-auto flex items-center justify-center mb-3">
            <Wallet className="w-7 h-7" />
          </div>

          <span className="text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold">
            {budget.period} limit
          </span>
          <h2 className="text-3xl font-extrabold font-amount text-white tracking-tight mt-1">
            {formatPaise(budget.monthlyLimitPaise, profile.currencySymbol)}
          </h2>

          {/* Progress bar */}
          <div className="w-full bg-[#050505] rounded-full h-3 my-4 overflow-hidden border border-[#27272A]">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                isOver ? 'bg-[#FF2D78]' : percent > 80 ? 'bg-[#FF5F1F]' : 'bg-[#00F5FF]'
              }`}
              style={{ width: `${Math.min(100, percent)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <span className="text-[#888888]">
              Spent: <strong className="text-white font-amount">{formatPaise(spentPaise, profile.currencySymbol)}</strong>
            </span>
            <span className="font-bold text-[#00F5FF]">{percent}% used</span>
          </div>
        </div>

        {/* Status Callout Card */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-4 space-y-3">
          <div className="flex items-center justify-between py-2 border-b border-[#27272A] text-xs">
            <span className="text-[#888888]">Status</span>
            <span
              className={`font-semibold px-2.5 py-0.5 rounded-full ${
                isOver
                  ? 'bg-[#FF2D78]/20 text-[#FF2D78]'
                  : 'bg-[#B6FF00]/15 text-[#B6FF00]'
              }`}
            >
              {isOver ? 'Over Budget' : 'Within Budget'}
            </span>
          </div>

          <div className="flex items-center justify-between py-2 border-b border-[#27272A] text-xs">
            <span className="text-[#888888]">Remaining Balance</span>
            <span
              className={`font-bold font-amount ${
                remainingPaise < 0 ? 'text-[#FF2D78]' : 'text-white'
              }`}
            >
              {formatPaise(remainingPaise, profile.currencySymbol)}
            </span>
          </div>

          <div className="flex items-center justify-between py-2 text-xs">
            <span className="text-[#888888]">Category</span>
            <span className="text-white font-medium">{budget.category}</span>
          </div>
        </div>

        {/* Action Buttons: Edit and Delete */}
        <div className="pt-2 space-y-3">
          <NeonPrimaryButton
            onClick={() => navigate('EditBudgetPage', { budgetId: budget.id })}
            variant="cyan"
            icon={<Edit3 className="w-4 h-4" />}
            data-testid="edit-budget-button"
          >
            Edit Budget / திருத்து
          </NeonPrimaryButton>

          {showDeleteConfirm ? (
            <div className="p-4 rounded-xl bg-red-950/30 border border-red-500/40 space-y-3">
              <div className="flex items-center gap-2 text-red-400 text-xs font-semibold">
                <AlertTriangle className="w-4 h-4" />
                <span>Delete this budget target permanently?</span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleDelete}
                  className="flex-1 py-2 px-3 rounded-lg bg-red-600 hover:bg-red-500 text-white font-semibold text-xs cursor-pointer"
                >
                  Yes, Delete
                </button>
                <button
                  onClick={() => setShowDeleteConfirm(false)}
                  className="flex-1 py-2 px-3 rounded-lg bg-[#121216] border border-[#27272A] text-[#CCC] text-xs cursor-pointer hover:bg-[#1A1A22]"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <NeonSecondaryButton
              onClick={() => setShowDeleteConfirm(true)}
              icon={<Trash2 className="w-4 h-4 text-[#FF2D78]" />}
              data-testid="delete-budget-button"
            >
              <span className="text-[#FF2D78]">Delete Budget</span>
            </NeonSecondaryButton>
          )}
        </div>

        <DeveloperFooter />
      </main>
    </div>
  );
};
