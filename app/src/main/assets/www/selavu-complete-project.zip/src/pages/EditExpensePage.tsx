import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import {
  NeonPrimaryButton,
  NeonSecondaryButton,
  CATEGORY_CONFIG,
  PAYMENT_METHOD_ICONS,
  ErrorMessage,
  EmptyState,
} from '../components/UIComponents';
import { ExpenseCategory, PaymentMethod } from '../types';
import { paiseToRupees, rupeesToPaise } from '../utils/finance';
import { Check, X, Store, FileText } from 'lucide-react';

const CATEGORIES: ExpenseCategory[] = [
  'Food & Dining',
  'Transport',
  'Groceries',
  'Bills & Utilities',
  'Shopping',
  'Entertainment',
  'Health',
  'Education',
  'Travel',
  'Others',
];

const PAYMENT_METHODS: PaymentMethod[] = [
  'UPI',
  'Cash',
  'Credit Card',
  'Debit Card',
  'Net Banking',
];

export const EditExpensePage: React.FC = () => {
  const { profile, expenses, navigation, updateExpense, navigate, goBack } = useApp();

  const expenseId = navigation.params?.expenseId;
  const existingExpense = expenses.find((e) => e.id === expenseId);

  const [amountStr, setAmountStr] = useState<string>('');
  const [merchant, setMerchant] = useState<string>('');
  const [category, setCategory] = useState<ExpenseCategory>('Food & Dining');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('UPI');
  const [date, setDate] = useState<string>('');
  const [time, setTime] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (existingExpense) {
      setAmountStr(paiseToRupees(existingExpense.amountPaise).toString());
      setMerchant(existingExpense.merchant);
      setCategory(existingExpense.category);
      setPaymentMethod(existingExpense.paymentMethod);
      setDate(existingExpense.date);
      setTime(existingExpense.time);
      setNotes(existingExpense.notes || '');
    }
  }, [existingExpense]);

  if (!existingExpense) {
    return (
      <div
        className="min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
        data-testid="edit-expense-page"
      >
        <AppHeader title="Expense Not Found" showBack={true} onBack={goBack} />
        <main className="max-w-md mx-auto w-full px-4 py-8 flex-1">
          <EmptyState
            title="Expense record not found"
            description="The item you wish to edit does not exist or has been removed."
            actionText="Go to History"
            onAction={() => navigate('HistoryPage')}
          />
        </main>
        <DeveloperFooter />
      </div>
    );
  }

  const handleSaveChanges = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const amt = parseFloat(amountStr);
    if (isNaN(amt) || amt <= 0) {
      setError('Please enter a valid amount greater than 0');
      return;
    }
    if (!merchant.trim()) {
      setError('Please enter a merchant or recipient name');
      return;
    }
    if (!date) {
      setError('Please select a valid date');
      return;
    }

    try {
      updateExpense(existingExpense.id, {
        amountPaise: rupeesToPaise(amt),
        merchant: merchant.trim(),
        category,
        paymentMethod,
        date,
        time: time || '12:00',
        notes: notes.trim(),
      });

      // Navigate back to details
      navigate('ExpenseDetailsPage', { expenseId: existingExpense.id });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to update expense');
    }
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="edit-expense-page"
    >
      <AppHeader
        title="Edit Expense"
        tamilSubtitle="செலவு திருத்து"
        showBack={true}
        onBack={goBack}
        closeIcon={true}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSaveChanges} className="space-y-5">
          {/* Amount input */}
          <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-4 text-center">
            <label className="text-xs font-semibold uppercase tracking-wider text-[#A1A1AA] block mb-1">
              Update Amount
            </label>
            <div className="flex items-center justify-center gap-1 my-2">
              <span className="text-3xl font-extrabold text-[#B6FF00] font-amount">
                {profile.currencySymbol}
              </span>
              <input
                type="number"
                step="any"
                min="0.5"
                placeholder="0"
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                className="w-48 bg-transparent text-4xl sm:text-5xl font-extrabold font-amount text-white text-center outline-none"
                required
              />
            </div>
          </div>

          {/* Merchant input */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
              Merchant / Store
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#888888]">
                <Store className="w-4 h-4" />
              </div>
              <input
                type="text"
                value={merchant}
                onChange={(e) => setMerchant(e.target.value)}
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-4 py-3 text-sm text-white outline-none"
                required
              />
            </div>
          </div>

          {/* Category Selection */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-2">
              Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {CATEGORIES.map((cat) => {
                const config = CATEGORY_CONFIG[cat];
                const Icon = config.icon;
                const isSelected = category === cat;

                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className={`flex items-center gap-2 p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#1A1A22] border-[#B6FF00] shadow-[0_0_10px_rgba(182,255,0,0.2)]'
                        : 'bg-[#121216] border-[#27272A] hover:border-[#444]'
                    }`}
                  >
                    <div
                      className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                      style={{ backgroundColor: config.bg, color: config.color }}
                    >
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span
                      className={`text-xs font-semibold truncate ${
                        isSelected ? 'text-[#B6FF00]' : 'text-[#CCC]'
                      }`}
                    >
                      {cat}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-2">
              Payment Method
            </label>
            <div className="flex flex-wrap gap-2">
              {PAYMENT_METHODS.map((pm) => {
                const Icon = PAYMENT_METHOD_ICONS[pm];
                const isSelected = paymentMethod === pm;

                return (
                  <button
                    key={pm}
                    type="button"
                    onClick={() => setPaymentMethod(pm)}
                    className={`flex items-center gap-1.5 py-2 px-3 rounded-xl border text-xs font-medium transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#00F5FF]/15 text-[#00F5FF] border-[#00F5FF]'
                        : 'bg-[#121216] text-[#A1A1AA] border-[#27272A] hover:border-[#444]'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{pm}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl px-3 py-2.5 text-xs text-white outline-none"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">Time</label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl px-3 py-2.5 text-xs text-white outline-none"
              />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">Notes</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl p-3 text-xs text-white outline-none resize-none"
            />
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <NeonPrimaryButton
              type="submit"
              icon={<Check className="w-4 h-4" />}
              data-testid="save-changes-button"
            >
              Save Changes
            </NeonPrimaryButton>

            <NeonSecondaryButton
              type="button"
              onClick={goBack}
              data-testid="cancel-edit-button"
            >
              Cancel
            </NeonSecondaryButton>
          </div>
        </form>

        <DeveloperFooter />
      </main>
    </div>
  );
};
