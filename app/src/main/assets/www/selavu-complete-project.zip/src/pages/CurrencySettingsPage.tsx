import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import { NeonPrimaryButton, NeonSecondaryButton } from '../components/UIComponents';
import { Check, Coins } from 'lucide-react';

interface CurrencyOption {
  code: string;
  symbol: string;
  name: string;
  locale: string;
}

const SUPPORTED_CURRENCIES: CurrencyOption[] = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee (Default)', locale: 'en-IN' },
  { code: 'USD', symbol: '$', name: 'US Dollar', locale: 'en-US' },
  { code: 'EUR', symbol: '€', name: 'Euro', locale: 'de-DE' },
  { code: 'GBP', symbol: '£', name: 'British Pound', locale: 'en-GB' },
  { code: 'AED', symbol: 'AED', name: 'UAE Dirham', locale: 'ar-AE' },
  { code: 'SGD', symbol: 'S$', name: 'Singapore Dollar', locale: 'en-SG' },
  { code: 'MYR', symbol: 'RM', name: 'Malaysian Ringgit', locale: 'ms-MY' },
];

export const CurrencySettingsPage: React.FC = () => {
  const { profile, updateSettings, saveProfile, navigate } = useApp();

  const [selectedCode, setSelectedCode] = useState<string>(profile.currencyCode || 'INR');

  const handleSave = () => {
    const matched = SUPPORTED_CURRENCIES.find((c) => c.code === selectedCode) || SUPPORTED_CURRENCIES[0];
    saveProfile({
      currencyCode: matched.code,
      currencySymbol: matched.symbol,
    });
    updateSettings({
      currencyCode: matched.code,
      currencySymbol: matched.symbol,
    });
    navigate('SettingsPage');
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="currency-settings-page"
    >
      <AppHeader
        title="Currency Settings"
        tamilSubtitle="நாணய அமைப்புகள்"
        showBack={true}
        onBack={() => navigate('SettingsPage')}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        <div className="rounded-xl bg-[#121216] border border-[#27272A] p-4 text-xs text-[#A1A1AA] leading-relaxed">
          Select your default currency. All financial calculations, allowances, and spending charts will display using this symbol.
        </div>

        <div className="space-y-2">
          {SUPPORTED_CURRENCIES.map((cur) => {
            const isSelected = selectedCode === cur.code;

            return (
              <button
                key={cur.code}
                type="button"
                onClick={() => setSelectedCode(cur.code)}
                className={`w-full flex items-center justify-between p-3.5 rounded-xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-[#1A1A22] border-[#B6FF00] shadow-[0_0_12px_rgba(182,255,0,0.2)]'
                    : 'bg-[#121216] border-[#27272A] hover:border-[#555]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-amount font-bold text-base ${
                      isSelected
                        ? 'bg-[#B6FF00]/20 text-[#B6FF00]'
                        : 'bg-[#0B0B0F] text-[#888888]'
                    }`}
                  >
                    {cur.symbol}
                  </div>
                  <div className="text-left">
                    <h4 className="text-sm font-semibold text-white">{cur.name}</h4>
                    <span className="text-xs text-[#888888] font-mono">{cur.code}</span>
                  </div>
                </div>

                {isSelected && (
                  <div className="w-6 h-6 rounded-full bg-[#B6FF00] text-black flex items-center justify-center">
                    <Check className="w-4 h-4 stroke-[3]" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        <div className="pt-3 flex flex-col sm:flex-row gap-3">
          <NeonPrimaryButton
            onClick={handleSave}
            icon={<Check className="w-4 h-4" />}
            data-testid="save-currency-button"
          >
            Save Preference
          </NeonPrimaryButton>

          <NeonSecondaryButton
            onClick={() => navigate('SettingsPage')}
            data-testid="cancel-currency-button"
          >
            Cancel
          </NeonSecondaryButton>
        </div>

        <DeveloperFooter />
      </main>
    </div>
  );
};
