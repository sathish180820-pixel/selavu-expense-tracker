import React from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import {
  TransactionListItem,
  EmptyState,
  CATEGORY_CONFIG,
} from '../components/UIComponents';
import { ExpenseCategory } from '../types';
import { formatPaise } from '../utils/finance';
import { PieChart, ArrowLeft, TrendingUp } from 'lucide-react';

export const CategoryAnalyticsPage: React.FC = () => {
  const { profile, expenses, navigation, navigate } = useApp();

  const selectedCategory =
    navigation.params?.category || ('Food & Dining' as ExpenseCategory);
  const period = navigation.params?.period || 'this_month';

  // Filter transactions for this category
  const categoryExpenses = expenses.filter((e) => e.category === selectedCategory);
  const totalCategorySpent = categoryExpenses.reduce((sum, e) => sum + e.amountPaise, 0);
  const totalAllSpent = expenses.reduce((sum, e) => sum + e.amountPaise, 0);
  const percentOfAll =
    totalAllSpent > 0 ? Math.round((totalCategorySpent / totalAllSpent) * 100) : 0;
  const avgAmount =
    categoryExpenses.length > 0 ? Math.round(totalCategorySpent / categoryExpenses.length) : 0;

  const config = CATEGORY_CONFIG[selectedCategory] || CATEGORY_CONFIG.Others;
  const CategoryIcon = config.icon;

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="category-analytics-page"
    >
      <AppHeader
        title={`${selectedCategory} Details`}
        tamilSubtitle="வகை பகுப்பாய்வு"
        showBack={true}
        onBack={() => navigate('AnalyticsPage')}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {/* Category Header Card */}
        <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-6 text-center relative overflow-hidden">
          <div
            className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center mb-3 shadow-lg"
            style={{ backgroundColor: config.bg, color: config.color }}
          >
            <CategoryIcon className="w-8 h-8" />
          </div>

          <h2 className="text-3xl font-extrabold font-amount text-white tracking-tight">
            {formatPaise(totalCategorySpent, profile.currencySymbol)}
          </h2>
          <p className="text-xs text-[#A1A1AA] mt-1">
            {percentOfAll}% of your total recorded spending
          </p>

          <div className="grid grid-cols-2 gap-3 mt-4 pt-4 border-t border-[#27272A]">
            <div className="bg-[#0B0B0F] p-2.5 rounded-xl border border-[#27272A]/70">
              <span className="text-[10px] text-[#888888] uppercase block">Transactions</span>
              <span className="text-sm font-bold font-amount text-white">
                {categoryExpenses.length}
              </span>
            </div>
            <div className="bg-[#0B0B0F] p-2.5 rounded-xl border border-[#27272A]/70">
              <span className="text-[10px] text-[#888888] uppercase block">Avg / Transaction</span>
              <span className="text-sm font-bold font-amount text-[#B6FF00]">
                {formatPaise(avgAmount, profile.currencySymbol)}
              </span>
            </div>
          </div>
        </div>

        {/* Transactions under this category */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Transaction Log</h3>
            <span className="text-xs text-[#888888]">
              {categoryExpenses.length} entries
            </span>
          </div>

          {categoryExpenses.length === 0 ? (
            <EmptyState
              title={`No expenses under ${selectedCategory}`}
              description="Record a transaction with this category to see details here."
              actionText="Add Expense"
              onAction={() => navigate('AddExpensePage')}
            />
          ) : (
            <div className="space-y-2">
              {categoryExpenses.map((exp) => (
                <TransactionListItem
                  key={exp.id}
                  expense={exp}
                  currencySymbol={profile.currencySymbol}
                  onClick={() =>
                    navigate('ExpenseDetailsPage', {
                      expenseId: exp.id,
                      fromPage: 'CategoryAnalyticsPage',
                    })
                  }
                />
              ))}
            </div>
          )}
        </div>

        <DeveloperFooter />
      </main>
    </div>
  );
};
