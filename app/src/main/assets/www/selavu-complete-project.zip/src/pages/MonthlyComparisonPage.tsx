import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import { formatPaise } from '../utils/finance';
import { BarChart3, TrendingDown, TrendingUp, Calendar } from 'lucide-react';

export const MonthlyComparisonPage: React.FC = () => {
  const { profile, expenses, navigate } = useApp();
  const [selectedView, setSelectedView] = useState<'months' | 'quarters'>('months');

  // Compute monthly totals for current month, last month, and 2 months ago
  const monthlyData = useMemo(() => {
    const now = new Date();
    const months = [
      { offset: 0, label: 'Current Month' },
      { offset: 1, label: 'Last Month' },
      { offset: 2, label: '2 Months Ago' },
    ];

    return months.map(({ offset, label }) => {
      const d = new Date(now.getFullYear(), now.getMonth() - offset, 1);
      const year = d.getFullYear();
      const month = d.getMonth();
      const monthName = d.toLocaleString('default', { month: 'short' });

      const monthExpenses = expenses.filter((e) => {
        const expD = new Date(e.date + 'T00:00:00');
        return expD.getFullYear() === year && expD.getMonth() === month;
      });

      const totalPaise = monthExpenses.reduce((sum, e) => sum + e.amountPaise, 0);
      return {
        monthName: `${monthName} ${year}`,
        label,
        totalPaise,
        count: monthExpenses.length,
      };
    });
  }, [expenses]);

  const maxMonthPaise = Math.max(...monthlyData.map((m) => m.totalPaise), 100000);
  const currentMonthTotal = monthlyData[0].totalPaise;
  const lastMonthTotal = monthlyData[1].totalPaise;
  const diffPaise = currentMonthTotal - lastMonthTotal;
  const isLower = diffPaise <= 0;

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="monthly-comparison-page"
    >
      <AppHeader
        title="Monthly Comparison"
        tamilSubtitle="மாத ஒப்பீடு"
        showBack={true}
        onBack={() => navigate('AnalyticsPage')}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {/* Comparison Header Card */}
        <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-5 text-center">
          <span className="text-xs uppercase tracking-wider text-[#A1A1AA] font-semibold">
            Month-over-Month Delta
          </span>
          <div className="flex items-center justify-center gap-2 mt-2">
            {isLower ? (
              <span className="p-2 rounded-full bg-[#B6FF00]/15 text-[#B6FF00]">
                <TrendingDown className="w-5 h-5" />
              </span>
            ) : (
              <span className="p-2 rounded-full bg-[#FF2D78]/15 text-[#FF2D78]">
                <TrendingUp className="w-5 h-5" />
              </span>
            )}
            <h2
              className={`text-2xl sm:text-3xl font-extrabold font-amount ${
                isLower ? 'text-[#B6FF00]' : 'text-[#FF2D78]'
              }`}
            >
              {isLower ? '-' : '+'}
              {formatPaise(Math.abs(diffPaise), profile.currencySymbol)}
            </h2>
          </div>
          <p className="text-xs text-[#888888] mt-1">
            {isLower
              ? 'Great job! You spent less than last month so far.'
              : 'You have spent more than the previous month.'}
          </p>
        </div>

        {/* Visual Bar Comparison */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Monthly Comparison Chart</h3>
            <span className="text-xs text-[#888888]">Outflow Trend</span>
          </div>

          <div className="space-y-4 pt-2">
            {monthlyData.map((m, index) => {
              const heightPct = Math.round((m.totalPaise / maxMonthPaise) * 100);
              const isCurrent = index === 0;

              return (
                <div key={m.monthName} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <div>
                      <span className="font-semibold text-white">{m.monthName}</span>
                      <span className="text-[10px] text-[#888888] ml-1.5">({m.label})</span>
                    </div>
                    <span className="font-bold font-amount text-white">
                      {formatPaise(m.totalPaise, profile.currencySymbol)}
                    </span>
                  </div>

                  <div className="w-full bg-[#050505] rounded-full h-3 overflow-hidden border border-[#27272A]">
                    <div
                      className={`h-full rounded-full transition-all duration-700 ${
                        isCurrent
                          ? 'bg-gradient-to-r from-[#B6FF00] to-[#00F5FF]'
                          : 'bg-[#27272A]'
                      }`}
                      style={{ width: `${Math.max(5, heightPct)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Projected Savings Card */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-4 space-y-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-[#00F5FF]">
            Savings Forecast
          </h4>
          <p className="text-xs text-[#A1A1AA] leading-relaxed">
            Based on your monthly salary of{' '}
            <strong className="text-white font-amount">
              {formatPaise(profile.monthlySalaryPaise, profile.currencySymbol)}
            </strong>{' '}
            and current expenditure, you are on track to preserve{' '}
            <strong className="text-[#B6FF00] font-amount">
              {formatPaise(
                Math.max(0, profile.monthlySalaryPaise - currentMonthTotal),
                profile.currencySymbol
              )}
            </strong>{' '}
            this cycle.
          </p>
        </div>

        <DeveloperFooter />
      </main>
    </div>
  );
};
