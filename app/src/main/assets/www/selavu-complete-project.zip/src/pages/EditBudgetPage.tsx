import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import {
  NeonPrimaryButton,
  NeonSecondaryButton,
  ErrorMessage,
  EmptyState,
} from '../components/UIComponents';
import { ExpenseCategory } from '../types';
import { paiseToRupees, rupeesToPaise } from '../utils/finance';
import { Check } from 'lucide-react';

const CATEGORY_OPTIONS: (ExpenseCategory | 'Overall')[] = [
  'Overall',
  'Food & Dining',
  'Transport',
  'Groceries',
  'Bills & Utilities',
  'Shopping',
  'Entertainment',
  'Health',
  'Education',
  'Travel',
  'Others',
];

export const EditBudgetPage: React.FC = () => {
  const { profile, budgets, navigation, updateBudget, navigate, goBack } = useApp();

  const budgetId = navigation.params?.budgetId;
  const existingBudget = budgets.find((b) => b.id === budgetId);

  const [category, setCategory] = useState<ExpenseCategory | 'Overall'>('Food & Dining');
  const [limitStr, setLimitStr] = useState<string>('');
  const [period, setPeriod] = useState<'monthly' | 'weekly'>('monthly');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (existingBudget) {
      setCategory(existingBudget.category);
      setLimitStr(paiseToRupees(existingBudget.monthlyLimitPaise).toString());
      setPeriod(existingBudget.period);
    }
  }, [existingBudget]);

  if (!existingBudget) {
    return (
      <div
        className="min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
        data-testid="edit-budget-page"
      >
        <AppHeader title="Budget Not Found" showBack={true} onBack={goBack} />
        <main className="max-w-md mx-auto w-full px-4 py-8 flex-1">
          <EmptyState
            title="Budget record not found"
            description="The budget target you are trying to edit does not exist."
            actionText="Go to Budgets"
            onAction={() => navigate('BudgetsPage')}
          />
        </main>
        <DeveloperFooter />
      </div>
    );
  }

  const handleSaveChanges = (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    const limitNum = parseFloat(limitStr);
    if (isNaN(limitNum) || limitNum <= 0) {
      setError('Please enter a valid budget limit');
      return;
    }

    try {
      updateBudget(existingBudget.id, {
        category,
        monthlyLimitPaise: rupeesToPaise(limitNum),
        period,
      });

      navigate('BudgetsPage');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to update budget');
    }
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="edit-budget-page"
    >
      <AppHeader
        title="Edit Budget"
        tamilSubtitle="பட்ஜெட் திருத்து"
        showBack={true}
        onBack={() => navigate('BudgetDetailsPage', { budgetId: existingBudget.id })}
        closeIcon={true}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleSaveChanges} className="space-y-5">
          {/* Amount input */}
          <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-4 text-center">
            <label className="text-xs font-semibold uppercase tracking-wider text-[#A1A1AA] block mb-1">
              Update Budget Limit
            </label>
            <div className="flex items-center justify-center gap-1 my-2">
              <span className="text-3xl font-extrabold text-[#00F5FF] font-amount">
                {profile.currencySymbol}
              </span>
              <input
                type="number"
                step="500"
                min="500"
                value={limitStr}
                onChange={(e) => setLimitStr(e.target.value)}
                className="w-48 bg-transparent text-4xl sm:text-5xl font-extrabold font-amount text-white text-center outline-none"
                required
              />
            </div>
          </div>

          {/* Period selector */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
              Budget Period
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setPeriod('monthly')}
                className={`py-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  period === 'monthly'
                    ? 'bg-[#00F5FF]/20 text-[#00F5FF] border-[#00F5FF]'
                    : 'bg-[#121216] text-[#A1A1AA] border-[#27272A]'
                }`}
              >
                Monthly
              </button>
              <button
                type="button"
                onClick={() => setPeriod('weekly')}
                className={`py-2.5 rounded-xl border text-xs font-semibold transition-all cursor-pointer ${
                  period === 'weekly'
                    ? 'bg-[#00F5FF]/20 text-[#00F5FF] border-[#00F5FF]'
                    : 'bg-[#121216] text-[#A1A1AA] border-[#27272A]'
                }`}
              >
                Weekly
              </button>
            </div>
          </div>

          {/* Category selection */}
          <div>
            <label className="block text-xs font-medium text-[#A1A1AA] mb-2">Category</label>
            <div className="grid grid-cols-2 gap-2">
              {CATEGORY_OPTIONS.map((cat) => {
                const isSelected = category === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setCategory(cat)}
                    className={`p-2.5 rounded-xl border text-left text-xs font-semibold transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#1A1A22] text-[#00F5FF] border-[#00F5FF]'
                        : 'bg-[#121216] text-[#CCC] border-[#27272A] hover:border-[#444]'
                    }`}
                  >
                    <span>{cat}</span>
                    {isSelected && <Check className="w-3.5 h-3.5 text-[#00F5FF]" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3">
            <NeonPrimaryButton
              type="submit"
              variant="cyan"
              icon={<Check className="w-4 h-4" />}
              data-testid="save-budget-changes-button"
            >
              Save Changes
            </NeonPrimaryButton>

            <NeonSecondaryButton
              type="button"
              onClick={() => navigate('BudgetDetailsPage', { budgetId: existingBudget.id })}
              data-testid="cancel-edit-budget-button"
            >
              Cancel
            </NeonSecondaryButton>
          </div>
        </form>

        <DeveloperFooter />
      </main>
    </div>
  );
};
