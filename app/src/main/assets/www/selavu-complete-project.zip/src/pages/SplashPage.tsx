import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { ArrowRight, Sparkles } from 'lucide-react';

export const SplashPage: React.FC = () => {
  const { profile, navigate } = useApp();
  const [stage, setStage] = useState<number>(0);

  useEffect(() => {
    // Stage 1: Central Rupee fades in & rings expand (0ms)
    // Stage 2: Rupee cash notes flow along curved paths (800ms)
    // Stage 3: Convergence and Logo + App Title reveal (1800ms)
    // Stage 4: Ready / Auto-navigate (3600ms)
    const t1 = setTimeout(() => setStage(1), 300);
    const t2 = setTimeout(() => setStage(2), 1000);
    const t3 = setTimeout(() => setStage(3), 2000);
    const t4 = setTimeout(() => {
      handleProceed();
    }, 4500);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, []);

  const handleProceed = () => {
    if (profile.onboardingComplete) {
      navigate('HomePage');
    } else {
      navigate('OnboardingWelcomePage');
    }
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between items-center overflow-hidden px-4 py-6 select-none"
      data-testid="splash-page"
    >
      {/* Background ambient neon glow orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full bg-[#B6FF00]/10 blur-[100px] pointer-events-none" />
      <div className="absolute top-1/3 left-1/3 w-60 h-60 rounded-full bg-[#00F5FF]/10 blur-[80px] pointer-events-none" />
      <div className="absolute bottom-1/3 right-1/4 w-60 h-60 rounded-full bg-[#FF2D78]/10 blur-[80px] pointer-events-none" />

      {/* Top Header spacer & Skip button */}
      <div className="w-full max-w-md flex justify-end pt-2 z-20">
        <button
          onClick={handleProceed}
          className="text-xs text-[#888888] hover:text-[#B6FF00] py-1.5 px-3 rounded-full bg-[#121216]/80 border border-[#27272A] flex items-center gap-1 transition-all cursor-pointer"
        >
          <span>Skip</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Main Animation Area */}
      <div className="relative w-full max-w-sm h-96 flex flex-col items-center justify-center z-10">
        {/* Animated Cash Flow SVG Canvas */}
        <svg
          className="absolute inset-0 w-full h-full pointer-events-none"
          viewBox="0 0 360 360"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Subtle curved orbital paths */}
          <circle
            cx="180"
            cy="180"
            r="120"
            stroke="#27272A"
            strokeWidth="1"
            strokeDasharray="4 6"
            className="opacity-40"
          />
          <circle
            cx="180"
            cy="180"
            r="80"
            stroke="#B6FF00"
            strokeWidth="1"
            strokeDasharray="6 8"
            className={`transition-all duration-1000 ${
              stage >= 1 ? 'opacity-30 scale-100' : 'opacity-0 scale-75'
            }`}
          />

          {/* Cash Note 1: Olive Green ₹500 styled bill flowing in */}
          <g
            className={`transition-all duration-1000 ease-out ${
              stage >= 2
                ? 'opacity-85 translate-x-0 translate-y-0 scale-100'
                : 'opacity-0 -translate-x-24 -translate-y-20 scale-50'
            }`}
            style={{ transformOrigin: '180px 180px' }}
          >
            <rect
              x="50"
              y="90"
              width="60"
              height="32"
              rx="4"
              fill="#1F3316"
              stroke="#68D391"
              strokeWidth="1.2"
              transform="rotate(-18 80 106)"
            />
            <text
              x="62"
              y="110"
              fill="#68D391"
              fontSize="10"
              fontWeight="bold"
              transform="rotate(-18 80 106)"
              fontFamily="Space Grotesk"
            >
              ₹500
            </text>
            <circle cx="95" cy="106" r="6" fill="#68D391" opacity="0.3" transform="rotate(-18 80 106)" />
          </g>

          {/* Cash Note 2: Vibrant Cyan ₹100 styled bill */}
          <g
            className={`transition-all duration-1000 ease-out delay-150 ${
              stage >= 2
                ? 'opacity-85 translate-x-0 translate-y-0 scale-100'
                : 'opacity-0 translate-x-28 -translate-y-16 scale-50'
            }`}
            style={{ transformOrigin: '180px 180px' }}
          >
            <rect
              x="245"
              y="100"
              width="56"
              height="30"
              rx="4"
              fill="#102A38"
              stroke="#00F5FF"
              strokeWidth="1.2"
              transform="rotate(15 273 115)"
            />
            <text
              x="256"
              y="119"
              fill="#00F5FF"
              fontSize="10"
              fontWeight="bold"
              transform="rotate(15 273 115)"
              fontFamily="Space Grotesk"
            >
              ₹100
            </text>
            <circle cx="288" cy="115" r="5" fill="#00F5FF" opacity="0.3" transform="rotate(15 273 115)" />
          </g>

          {/* Cash Note 3: Bright Orange ₹200 styled bill */}
          <g
            className={`transition-all duration-1000 ease-out delay-300 ${
              stage >= 2
                ? 'opacity-85 translate-x-0 translate-y-0 scale-100'
                : 'opacity-0 -translate-x-20 translate-y-24 scale-50'
            }`}
            style={{ transformOrigin: '180px 180px' }}
          >
            <rect
              x="60"
              y="230"
              width="58"
              height="30"
              rx="4"
              fill="#331E12"
              stroke="#FF8A00"
              strokeWidth="1.2"
              transform="rotate(12 89 245)"
            />
            <text
              x="72"
              y="249"
              fill="#FF8A00"
              fontSize="10"
              fontWeight="bold"
              transform="rotate(12 89 245)"
              fontFamily="Space Grotesk"
            >
              ₹200
            </text>
          </g>

          {/* Cash Note 4: Magenta/Pink ₹2000 styled bill */}
          <g
            className={`transition-all duration-1000 ease-out delay-500 ${
              stage >= 2
                ? 'opacity-85 translate-x-0 translate-y-0 scale-100'
                : 'opacity-0 translate-x-24 translate-y-24 scale-50'
            }`}
            style={{ transformOrigin: '180px 180px' }}
          >
            <rect
              x="240"
              y="225"
              width="62"
              height="32"
              rx="4"
              fill="#331024"
              stroke="#FF2D78"
              strokeWidth="1.2"
              transform="rotate(-15 271 241)"
            />
            <text
              x="250"
              y="245"
              fill="#FF2D78"
              fontSize="10"
              fontWeight="bold"
              transform="rotate(-15 271 241)"
              fontFamily="Space Grotesk"
            >
              ₹2000
            </text>
          </g>

          {/* Floating glowing rupee particles */}
          <g className={`transition-all duration-1000 ${stage >= 2 ? 'opacity-80' : 'opacity-0'}`}>
            <circle cx="110" cy="160" r="3" fill="#B6FF00" />
            <circle cx="260" cy="180" r="2.5" fill="#00F5FF" />
            <circle cx="160" cy="80" r="2" fill="#FF2D78" />
            <circle cx="210" cy="270" r="3" fill="#39FF14" />
          </g>
        </svg>

        {/* Central Glowing ₹ Symbol & Logo Core */}
        <div className="relative flex items-center justify-center">
          {/* Outer glowing pulsing ring */}
          <div
            className={`absolute w-32 h-32 rounded-full border border-[#B6FF00]/40 transition-all duration-1000 ${
              stage >= 1 ? 'scale-100 opacity-100 animate-pulse' : 'scale-50 opacity-0'
            }`}
          />
          <div
            className={`absolute w-24 h-24 rounded-full border border-[#00F5FF]/30 transition-all duration-1000 delay-100 ${
              stage >= 1 ? 'scale-100 opacity-100' : 'scale-50 opacity-0'
            }`}
          />

          {/* Core Rupee Badge */}
          <div
            className={`relative w-20 h-20 rounded-2xl bg-gradient-to-br from-[#1A1A22] to-[#0B0B0F] border-2 border-[#B6FF00] flex items-center justify-center shadow-[0_0_35px_rgba(182,255,0,0.4)] transition-all duration-700 ${
              stage >= 1 ? 'scale-100 rotate-0 opacity-100' : 'scale-50 rotate-45 opacity-0'
            }`}
          >
            <span className="text-4xl font-extrabold font-amount text-[#B6FF00] text-glow-lime">
              ₹
            </span>
          </div>
        </div>

        {/* Title & Tagline Reveal */}
        <div
          className={`text-center mt-6 transition-all duration-700 ${
            stage >= 3 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <div className="flex items-center justify-center gap-2">
            <h1 className="text-3xl sm:text-4xl font-extrabold font-tamil tracking-wide text-white">
              செலவு
            </h1>
            <span className="text-xl font-bold text-[#B6FF00] tracking-tight">
              (Selavu)
            </span>
          </div>
          <p className="text-sm font-medium text-[#A1A1AA] mt-1.5 tracking-wider">
            Your Money. Your Control.
          </p>
        </div>
      </div>

      {/* Bottom Action & Footer */}
      <div className="w-full max-w-sm flex flex-col items-center gap-3 z-20">
        <button
          onClick={handleProceed}
          className="w-full py-3.5 px-6 rounded-xl bg-[#B6FF00] text-black font-semibold text-sm hover:bg-[#c4ff2e] shadow-[0_0_20px_rgba(182,255,0,0.3)] transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
        >
          <span>Get Started</span>
          <ArrowRight className="w-4 h-4" />
        </button>

        <DeveloperFooter />
      </div>
    </div>
  );
};
