import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { NeonPrimaryButton, ErrorMessage } from '../components/UIComponents';
import { AppHeader } from '../components/AppHeader';
import { Target, CheckCircle2, ArrowRight } from 'lucide-react';
import { paiseToRupees, rupeesToPaise, formatRupees, calculateMonthlyAllowance } from '../utils/finance';

export const SavingsGoalPage: React.FC = () => {
  const { profile, saveProfile, navigate } = useApp();
  const salaryPaise = profile.monthlySalaryPaise || rupeesToPaise(75000);
  const initialGoalNum = profile.savingsGoalPaise > 0 ? paiseToRupees(profile.savingsGoalPaise) : Math.round(paiseToRupees(salaryPaise) * 0.3);

  const [goalStr, setGoalStr] = useState(initialGoalNum.toString());
  const [error, setError] = useState<string | null>(null);

  const goalNum = parseFloat(goalStr) || 0;
  const goalPaise = rupeesToPaise(goalNum);
  const salaryNum = paiseToRupees(salaryPaise);
  const allowancePaise = calculateMonthlyAllowance(salaryPaise, goalPaise);
  const allowanceNum = paiseToRupees(allowancePaise);
  const dailyAllowanceNum = Math.round(allowanceNum / 30);
  const savingsPercent = salaryNum > 0 ? Math.min(100, Math.round((goalNum / salaryNum) * 100)) : 0;

  const handleFinishSetup = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (goalNum < 0) {
      setError('Savings goal cannot be negative');
      return;
    }
    if (goalNum > salaryNum) {
      setError('Savings goal cannot exceed your total monthly salary');
      return;
    }

    setError(null);
    saveProfile({
      savingsGoalPaise: goalPaise,
      onboardingComplete: true,
    });
    navigate('HomePage');
  };

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="savings-goal-page"
    >
      <AppHeader
        title="Savings Target"
        tamilSubtitle="சேமிப்பு இலக்கு"
        showBack={true}
        onBack={() => navigate('ProfileSetupPage')}
      />

      <div className="flex-1 max-w-sm mx-auto w-full px-5 py-6 flex flex-col justify-center">
        <div className="mb-6">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#B6FF00]">
            Step 3 of 3
          </span>
          <h2 className="text-2xl font-bold text-white mt-1">Set Your Monthly Savings</h2>
          <p className="text-xs text-[#A1A1AA] mt-1">
            Pay yourself first! We will calculate your remaining spending allowance automatically.
          </p>
        </div>

        {error && <ErrorMessage message={error} />}

        <form onSubmit={handleFinishSetup} className="space-y-5">
          {/* Savings Goal Input */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-[#A1A1AA]">
                Monthly Savings Goal ({profile.currencySymbol})
              </label>
              <span className="text-xs font-bold font-amount text-[#B6FF00]">
                {savingsPercent}% of salary
              </span>
            </div>

            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#B6FF00] font-bold text-base">
                ₹
              </div>
              <input
                type="number"
                min="0"
                max={salaryNum}
                step="500"
                value={goalStr}
                onChange={(e) => setGoalStr(e.target.value)}
                placeholder="25000"
                className="w-full bg-[#121216] border border-[#27272A] focus:border-[#B6FF00] rounded-xl pl-10 pr-4 py-3 text-base font-amount text-white placeholder-[#555] outline-none transition-all"
                required
              />
            </div>

            {/* Quick Percentage Chips */}
            <div className="flex items-center gap-2 mt-2.5">
              {[15, 20, 25, 30, 40].map((pct) => {
                const targetVal = Math.round((salaryNum * pct) / 100);
                return (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => setGoalStr(targetVal.toString())}
                    className={`flex-1 text-xs py-1.5 rounded-lg border font-medium transition-colors cursor-pointer ${
                      Math.abs(goalNum - targetVal) < 100
                        ? 'bg-[#B6FF00]/20 text-[#B6FF00] border-[#B6FF00]'
                        : 'bg-[#121216] text-[#A1A1AA] border-[#27272A] hover:border-[#888]'
                    }`}
                  >
                    {pct}%
                  </button>
                );
              })}
            </div>
          </div>

          {/* Computed Formula Summary Card */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-[#1A1A22] to-[#121216] border border-[#27272A] space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#888888]">Monthly Salary</span>
              <span className="font-semibold font-amount text-white">{formatRupees(salaryNum)}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#888888]">- Savings Target</span>
              <span className="font-semibold font-amount text-[#00F5FF]">
                -{formatRupees(goalNum)}
              </span>
            </div>
            <div className="pt-2 border-t border-[#27272A] flex items-center justify-between">
              <span className="text-xs font-semibold text-white">Monthly Allowance</span>
              <span className="text-base font-bold font-amount text-[#B6FF00]">
                {formatRupees(allowanceNum)}
              </span>
            </div>
            <div className="text-[11px] text-[#888888] bg-[#0B0B0F] p-2 rounded-lg text-center">
              Daily Safe Spend Limit: <strong className="text-white font-amount">{formatRupees(dailyAllowanceNum)} / day</strong>
            </div>
          </div>

          <div className="pt-3">
            <NeonPrimaryButton
              type="submit"
              icon={<CheckCircle2 className="w-4 h-4" />}
              data-testid="finish-setup-button"
            >
              Finish Setup & Enter Home
            </NeonPrimaryButton>
          </div>
        </form>
      </div>

      <DeveloperFooter />
    </div>
  );
};
