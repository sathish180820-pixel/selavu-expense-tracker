import React from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { AppHeader } from '../components/AppHeader';
import { ShieldCheck, Heart, Sparkles, Code2, Cpu } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { navigate, goBack } = useApp();

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between"
      data-testid="about-page"
    >
      <AppHeader
        title="About Selavu"
        tamilSubtitle="பற்றி"
        showBack={true}
        onBack={goBack}
      />

      <main className="max-w-md mx-auto w-full px-4 py-4 flex-1 space-y-5">
        {/* Logo & Identity Banner */}
        <div className="rounded-2xl bg-gradient-to-b from-[#1A1A22] to-[#121216] border border-[#27272A] p-6 text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#121216] to-[#1A1A22] border-2 border-[#B6FF00] mx-auto flex items-center justify-center mb-3 shadow-[0_0_20px_rgba(182,255,0,0.3)]">
            <span className="text-3xl font-extrabold font-amount text-[#B6FF00]">₹</span>
          </div>

          <div className="flex items-center justify-center gap-2">
            <h2 className="text-2xl font-bold font-tamil text-white">செலவு</h2>
            <span className="text-xl font-bold text-[#B6FF00]">(Selavu)</span>
          </div>
          <p className="text-xs text-[#A1A1AA] mt-1 font-medium">Your Money. Your Control.</p>

          <div className="mt-4 pt-4 border-t border-[#27272A] flex items-center justify-center gap-4 text-xs text-[#888888]">
            <span>Version 1.0.0</span>
            <span>•</span>
            <span>Android Production Build</span>
          </div>
        </div>

        {/* Developer Attribution Card */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-5 space-y-3 text-center">
          <div className="w-10 h-10 rounded-full bg-[#B6FF00]/15 text-[#B6FF00] mx-auto flex items-center justify-center">
            <Code2 className="w-5 h-5" />
          </div>

          <div>
            <span className="text-xs text-[#888888] uppercase tracking-wider block">Lead Architect & Developer</span>
            <h3 className="text-lg font-bold font-tamil text-white mt-0.5">மூ சதீஷ்</h3>
            <p className="text-xs text-[#A1A1AA] mt-1">
              Crafted for seamless, distraction-free expense tracking with native Indian Rupee aesthetics.
            </p>
          </div>
        </div>

        {/* Core Principles */}
        <div className="rounded-2xl bg-[#121216] border border-[#27272A] p-4 space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-[#00F5FF]">
            Architecture & Privacy
          </h4>

          <div className="space-y-2.5 text-xs text-[#A1A1AA] leading-relaxed">
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-[#B6FF00] shrink-0 mt-0.5" />
              <p>
                <strong className="text-white">Zero Cloud Tracking:</strong> All records remain locally on your phone's persistent storage. No telemetry or third-party servers.
              </p>
            </div>

            <div className="flex items-start gap-2.5">
              <Cpu className="w-4 h-4 text-[#00F5FF] shrink-0 mt-0.5" />
              <p>
                <strong className="text-white">Integer Paise Precision:</strong> Calculations are performed using safe integer paise to avoid IEEE-754 currency rounding errors.
              </p>
            </div>

            <div className="flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-[#FF2D78] shrink-0 mt-0.5" />
              <p>
                <strong className="text-white">Allowance Engine:</strong> Dynamic remaining allowance equation prevents overspending before month-end.
              </p>
            </div>
          </div>
        </div>

        <DeveloperFooter />
      </main>
    </div>
  );
};
