import React from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { NeonPrimaryButton } from '../components/UIComponents';
import { ShieldCheck, Zap, PieChart, ArrowRight, Coins } from 'lucide-react';

export const OnboardingWelcomePage: React.FC = () => {
  const { navigate } = useApp();

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between px-5 py-6 select-none"
      data-testid="onboarding-welcome-page"
    >
      {/* Background glow */}
      <div className="absolute top-10 right-0 w-64 h-64 bg-[#B6FF00]/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Header */}
      <div className="pt-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#121216] border border-[#B6FF00]/40 flex items-center justify-center">
            <span className="text-base font-bold font-amount text-[#B6FF00]">₹</span>
          </div>
          <span className="font-bold text-base tracking-wide text-white font-tamil">செலவு</span>
        </div>
        <span className="text-xs text-[#888888] font-medium">1 of 3</span>
      </div>

      {/* Main Feature Cards */}
      <div className="my-auto py-6 max-w-sm mx-auto w-full">
        <div className="mb-6">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#B6FF00] mb-1 block">
            Offline & Private
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight">
            Take Full Control of Your <span className="text-[#B6FF00] font-tamil">செலவு</span>
          </h2>
          <p className="text-sm text-[#A1A1AA] mt-2 leading-relaxed">
            Track daily expenses, set realistic monthly savings goals, and watch your finances flourish without internet reliance.
          </p>
        </div>

        {/* Feature Highlights */}
        <div className="space-y-3">
          <div className="p-3.5 rounded-xl bg-[#121216] border border-[#27272A] flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-[#B6FF00]/15 text-[#B6FF00] flex items-center justify-center shrink-0">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white">Instant UPI & Cash Tracking</h4>
              <p className="text-xs text-[#888888]">Quick-entry keypad and categories tailored for India</p>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#121216] border border-[#27272A] flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-[#00F5FF]/15 text-[#00F5FF] flex items-center justify-center shrink-0">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white">Automated Allowance Formula</h4>
              <p className="text-xs text-[#888888]">Remaining = Salary − Savings Goal − Expenses</p>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-[#121216] border border-[#27272A] flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-lg bg-[#FF2D78]/15 text-[#FF2D78] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white">100% Local & Secure</h4>
              <p className="text-xs text-[#888888]">Data stays strictly on your device with CSV & backup</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Button */}
      <div className="w-full max-w-sm mx-auto flex flex-col items-center gap-3 pb-2">
        <NeonPrimaryButton
          onClick={() => navigate('ProfileSetupPage')}
          icon={<ArrowRight className="w-4 h-4" />}
          data-testid="get-started-button"
        >
          Get Started
        </NeonPrimaryButton>

        <DeveloperFooter />
      </div>
    </div>
  );
};
