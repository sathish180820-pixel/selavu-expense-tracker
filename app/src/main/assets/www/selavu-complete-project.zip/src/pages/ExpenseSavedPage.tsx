import React, { useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { DeveloperFooter } from '../components/DeveloperFooter';
import { NeonPrimaryButton, NeonSecondaryButton } from '../components/UIComponents';
import { CheckCircle2, Home, Plus, ArrowRight, Store, Calendar, Wallet } from 'lucide-react';
import { formatPaise, calculatePeriodTotals } from '../utils/finance';
import confetti from 'canvas-confetti';

export const ExpenseSavedPage: React.FC = () => {
  const { profile, expenses, navigation, navigate } = useApp();
  const savedExpenseId = navigation.params?.savedExpenseId;
  const savedExpense = expenses.find((e) => e.id === savedExpenseId) || expenses[0];

  useEffect(() => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#B6FF00', '#00F5FF', '#FF2D78'],
      });
    } catch {
      // Ignore if confetti canvas not available
    }
  }, []);

  const periodTotals = calculatePeriodTotals(expenses);
  const monthlySalary = profile.monthlySalaryPaise;
  const savingsGoal = profile.savingsGoalPaise;
  const remainingAllowance = monthlySalary - savingsGoal - periodTotals.monthlyPaise;

  return (
    <div
      className="relative min-h-screen w-full bg-[#050505] text-white flex flex-col justify-between px-4 py-8"
      data-testid="expense-saved-page"
    >
      <div className="flex-1 max-w-sm mx-auto w-full flex flex-col items-center justify-center text-center">
        {/* Animated Checkmark Badge */}
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-[#121216] to-[#1A1A22] border-2 border-[#B6FF00] flex items-center justify-center text-[#B6FF00] mb-5 shadow-[0_0_30px_rgba(182,255,0,0.35)] animate-bounce">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <h2 className="text-2xl font-bold text-white mb-1">Expense Recorded!</h2>
        <p className="text-xs text-[#A1A1AA] mb-6">
          Your transaction was safely written to offline persistent storage.
        </p>

        {/* Transaction Summary Card */}
        {savedExpense && (
          <div className="w-full rounded-2xl bg-[#121216] border border-[#27272A] p-4 text-left space-y-3 mb-6">
            <div className="flex items-center justify-between pb-3 border-b border-[#27272A]">
              <div>
                <p className="text-xs text-[#888888]">Spent at</p>
                <h3 className="text-base font-bold text-white">{savedExpense.merchant}</h3>
              </div>
              <div className="text-right">
                <p className="text-xs text-[#888888]">Amount</p>
                <h3 className="text-lg font-bold font-amount text-[#FF5F1F]">
                  -{formatPaise(savedExpense.amountPaise, profile.currencySymbol)}
                </h3>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-[#888888] block">Category:</span>
                <span className="text-white font-medium">{savedExpense.category}</span>
              </div>
              <div>
                <span className="text-[#888888] block">Payment:</span>
                <span className="text-white font-medium">{savedExpense.paymentMethod}</span>
              </div>
              <div>
                <span className="text-[#888888] block">Date:</span>
                <span className="text-white font-medium">{savedExpense.date}</span>
              </div>
              <div>
                <span className="text-[#888888] block">Time:</span>
                <span className="text-white font-medium">{savedExpense.time}</span>
              </div>
            </div>

            {/* Allowance update callout */}
            <div className="mt-3 pt-3 border-t border-[#27272A] bg-[#0B0B0F] p-3 rounded-xl flex items-center justify-between">
              <span className="text-xs text-[#A1A1AA]">Updated Allowance:</span>
              <span
                className={`text-sm font-bold font-amount ${
                  remainingAllowance < 0 ? 'text-[#FF2D78]' : 'text-[#B6FF00]'
                }`}
              >
                {formatPaise(remainingAllowance, profile.currencySymbol)}
              </span>
            </div>
          </div>
        )}

        {/* Buttons per matrix: Back to Home & Add Another */}
        <div className="w-full space-y-3">
          <NeonPrimaryButton
            onClick={() => navigate('HomePage')}
            icon={<Home className="w-4 h-4" />}
            data-testid="back-to-home-button"
          >
            Back to Home / முகப்பு
          </NeonPrimaryButton>

          <NeonSecondaryButton
            onClick={() => navigate('AddExpensePage')}
            icon={<Plus className="w-4 h-4" />}
            data-testid="add-another-button"
          >
            Add Another Expense
          </NeonSecondaryButton>
        </div>
      </div>

      <DeveloperFooter />
    </div>
  );
};
