import os
import zipfile

def create_project_zip():
    base_dir = os.path.abspath(".")
    public_dir = os.path.join(base_dir, "public")
    os.makedirs(public_dir, exist_ok=True)
    
    zip_path = os.path.join(public_dir, "selavu-complete-project.zip")
    root_zip_path = os.path.join(base_dir, "selavu-complete-project.zip")
    
    # Artifact path
    artifact_dir = "/.aistudio/artifacts/brain/4570b93b-e50f-4812-8cc1-04dd25965c8b"
    os.makedirs(artifact_dir, exist_ok=True)
    artifact_zip_path = os.path.join(artifact_dir, "selavu-complete-project.zip")

    exclude_dirs = {"node_modules", "dist", ".git", ".playwright-cli", ".cache", "__pycache__"}
    exclude_files = {
        "selavu-complete-project.zip",
        "package-lock.json",
    }

    files_added = []

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(base_dir):
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith(".playwright")]
            
            for file in files:
                if file in exclude_files or file.endswith(".zip"):
                    continue
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, base_dir)
                
                # Exclude scripts/make_zip.py if unwanted, or keep it
                zipf.write(full_path, arcname=rel_path)
                files_added.append(rel_path)

    # Copy to root and artifacts
    import shutil
    shutil.copy2(zip_path, root_zip_path)
    shutil.copy2(zip_path, artifact_zip_path)

    print(f"Successfully packaged {len(files_added)} files into {zip_path}")
    print(f"File size: {os.path.getsize(zip_path)} bytes")

if __name__ == "__main__":
    create_project_zip()
