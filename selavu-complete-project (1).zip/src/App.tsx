import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { PageName } from './types';

// Import all 24 pages from registry
import { SplashPage } from './pages/SplashPage';
import { OnboardingWelcomePage } from './pages/OnboardingWelcomePage';
import { ProfileSetupPage } from './pages/ProfileSetupPage';
import { SavingsGoalPage } from './pages/SavingsGoalPage';
import { HomePage } from './pages/HomePage';
import { AddExpensePage } from './pages/AddExpensePage';
import { ExpenseSavedPage } from './pages/ExpenseSavedPage';
import { HistoryPage } from './pages/HistoryPage';
import { ExpenseDetailsPage } from './pages/ExpenseDetailsPage';
import { EditExpensePage } from './pages/EditExpensePage';
import { BudgetsPage } from './pages/BudgetsPage';
import { AddBudgetPage } from './pages/AddBudgetPage';
import { BudgetDetailsPage } from './pages/BudgetDetailsPage';
import { EditBudgetPage } from './pages/EditBudgetPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { CategoryAnalyticsPage } from './pages/CategoryAnalyticsPage';
import { MonthlyComparisonPage } from './pages/MonthlyComparisonPage';
import { ProfilePage } from './pages/ProfilePage';
import { EditProfilePage } from './pages/EditProfilePage';
import { SettingsPage } from './pages/SettingsPage';
import { CurrencySettingsPage } from './pages/CurrencySettingsPage';
import { BackupRestorePage } from './pages/BackupRestorePage';
import { ExportDataPage } from './pages/ExportDataPage';
import { AboutPage } from './pages/AboutPage';

import {
  Smartphone,
  Maximize2,
  ListTree,
  Wifi,
  Battery,
  Signal,
  X,
  CheckCircle2,
} from 'lucide-react';

const ALL_PAGES: { name: PageName; section: string; label: string }[] = [
  // A. Startup & Onboarding
  { name: 'SplashPage', section: 'Startup', label: '1. Splash Screen (Cash Flow)' },
  { name: 'OnboardingWelcomePage', section: 'Startup', label: '2. Welcome Onboarding' },
  { name: 'ProfileSetupPage', section: 'Startup', label: '3. Profile Setup' },
  { name: 'SavingsGoalPage', section: 'Startup', label: '4. Savings Target' },

  // B. Dashboard
  { name: 'HomePage', section: 'Dashboard', label: '5. Home Dashboard' },

  // C. Expenses
  { name: 'AddExpensePage', section: 'Expenses', label: '6. Add Expense' },
  { name: 'ExpenseSavedPage', section: 'Expenses', label: '7. Expense Saved Confirmation' },
  { name: 'HistoryPage', section: 'Expenses', label: '8. Transaction History' },
  { name: 'ExpenseDetailsPage', section: 'Expenses', label: '9. Expense Details' },
  { name: 'EditExpensePage', section: 'Expenses', label: '10. Edit Expense' },

  // D. Budgets
  { name: 'BudgetsPage', section: 'Budgets', label: '11. Budgets Overview' },
  { name: 'AddBudgetPage', section: 'Budgets', label: '12. Add Budget' },
  { name: 'BudgetDetailsPage', section: 'Budgets', label: '13. Budget Details' },
  { name: 'EditBudgetPage', section: 'Budgets', label: '14. Edit Budget' },

  // E. Analytics
  { name: 'AnalyticsPage', section: 'Analytics', label: '15. Spending Analytics' },
  { name: 'CategoryAnalyticsPage', section: 'Analytics', label: '16. Category Analytics' },
  { name: 'MonthlyComparisonPage', section: 'Analytics', label: '17. Monthly Comparison' },

  // F. Profile & Settings
  { name: 'ProfilePage', section: 'Settings', label: '18. User Profile' },
  { name: 'EditProfilePage', section: 'Settings', label: '19. Edit Profile' },
  { name: 'SettingsPage', section: 'Settings', label: '20. Settings' },
  { name: 'CurrencySettingsPage', section: 'Settings', label: '21. Currency Settings' },
  { name: 'BackupRestorePage', section: 'Settings', label: '22. Backup & Restore' },
  { name: 'ExportDataPage', section: 'Settings', label: '23. Export Data (CSV)' },
  { name: 'AboutPage', section: 'Settings', label: '24. About Selavu' },
];

const MainRouter: React.FC = () => {
  const { navigation, navigate } = useApp();
  const [deviceWidth, setDeviceWidth] = useState<'mobile' | 'wide' | 'full'>('mobile');
  const [showPageRegistryDrawer, setShowPageRegistryDrawer] = useState(false);

  // Render the requested active page
  const renderCurrentPage = () => {
    switch (navigation.currentPage) {
      case 'SplashPage':
        return <SplashPage />;
      case 'OnboardingWelcomePage':
        return <OnboardingWelcomePage />;
      case 'ProfileSetupPage':
        return <ProfileSetupPage />;
      case 'SavingsGoalPage':
        return <SavingsGoalPage />;
      case 'HomePage':
        return <HomePage />;
      case 'AddExpensePage':
        return <AddExpensePage />;
      case 'ExpenseSavedPage':
        return <ExpenseSavedPage />;
      case 'HistoryPage':
        return <HistoryPage />;
      case 'ExpenseDetailsPage':
        return <ExpenseDetailsPage />;
      case 'EditExpensePage':
        return <EditExpensePage />;
      case 'BudgetsPage':
        return <BudgetsPage />;
      case 'AddBudgetPage':
        return <AddBudgetPage />;
      case 'BudgetDetailsPage':
        return <BudgetDetailsPage />;
      case 'EditBudgetPage':
        return <EditBudgetPage />;
      case 'AnalyticsPage':
        return <AnalyticsPage />;
      case 'CategoryAnalyticsPage':
        return <CategoryAnalyticsPage />;
      case 'MonthlyComparisonPage':
        return <MonthlyComparisonPage />;
      case 'ProfilePage':
        return <ProfilePage />;
      case 'EditProfilePage':
        return <EditProfilePage />;
      case 'SettingsPage':
        return <SettingsPage />;
      case 'CurrencySettingsPage':
        return <CurrencySettingsPage />;
      case 'BackupRestorePage':
        return <BackupRestorePage />;
      case 'ExportDataPage':
        return <ExportDataPage />;
      case 'AboutPage':
        return <AboutPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white flex flex-col items-center justify-start overflow-x-hidden">
      {/* Top Testing Control Toolbar */}
      <nav
        aria-label="Testing Controls"
        className="w-full bg-[#0B0B0F]/90 border-b border-[#27272A] px-3 py-1.5 flex items-center justify-between text-xs z-50 select-none"
      >
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-[#B6FF00] shadow-[0_0_8px_#B6FF00]" />
          <span className="font-bold text-white tracking-wide">
            Selavu <span className="text-[#B6FF00] font-tamil">(செலவு)</span>
          </span>
          <span className="text-[#888888] hidden sm:inline">• Android Native Build</span>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Direct ZIP Download Button */}
          <a
            href="/selavu-complete-project.zip"
            download="selavu-complete-project.zip"
            className="flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-[#B6FF00]/15 border border-[#B6FF00]/40 hover:bg-[#B6FF00]/25 text-[#B6FF00] font-semibold cursor-pointer transition-all text-xs"
            title="Download Complete Project ZIP"
          >
            <Download className="w-3.5 h-3.5 text-[#B6FF00]" />
            <span className="hidden sm:inline">Download ZIP</span>
          </a>

          {/* Quick Page Registry Switcher Button */}
          <button
            onClick={() => setShowPageRegistryDrawer(true)}
            aria-label="Open 24 Pages Registry"
            className="flex items-center gap-1.5 py-1 px-2.5 rounded-lg bg-[#1A1A22] border border-[#27272A] hover:border-[#B6FF00]/50 text-white font-medium cursor-pointer transition-all"
          >
            <ListTree className="w-3.5 h-3.5 text-[#B6FF00]" />
            <span className="hidden xs:inline">All 24 Pages</span>
          </button>

          {/* Device Width Modes */}
          <div className="flex items-center bg-[#121216] border border-[#27272A] rounded-lg p-0.5">
            <button
              onClick={() => setDeviceWidth('mobile')}
              title="Mobile (393px)"
              className={`p-1 rounded ${
                deviceWidth === 'mobile' ? 'bg-[#27272A] text-[#B6FF00]' : 'text-[#888888]'
              } cursor-pointer`}
            >
              <Smartphone className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setDeviceWidth('full')}
              title="Full Responsive"
              className={`p-1 rounded ${
                deviceWidth === 'full' ? 'bg-[#27272A] text-[#B6FF00]' : 'text-[#888888]'
              } cursor-pointer`}
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </nav>

      {/* Android Device Shell Container */}
      <div
        className={`w-full transition-all duration-300 relative flex flex-col ${
          deviceWidth === 'mobile'
            ? 'max-w-[412px] h-[840px] max-h-[92vh] my-0 sm:my-3 sm:rounded-[40px] sm:border-[8px] sm:border-[#1E1E26] sm:shadow-[0_0_60px_rgba(0,0,0,0.9)] overflow-hidden bg-[#050505]'
            : deviceWidth === 'wide'
            ? 'max-w-2xl my-2 bg-[#050505]'
            : 'max-w-full bg-[#050505]'
        }`}
      >
        {/* Android Native Status Bar */}
        <div className="w-full bg-[#050505] px-6 py-2.5 flex items-center justify-between text-[11px] text-[#A1A1AA] select-none border-b border-transparent shrink-0 z-40">
          <span className="font-semibold font-amount text-white">11:05</span>
          {/* Simulated Camera Hole Punch */}
          <div className="w-3.5 h-3.5 rounded-full bg-black border border-[#222]" />
          <div className="flex items-center gap-1.5">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px]">98%</span>
              <Battery className="w-4 h-4 text-[#B6FF00]" />
            </div>
          </div>
        </div>

        {/* Current Active Page Screen with Smooth Scrolling */}
        <div className="w-full flex-1 overflow-y-auto relative bg-[#050505] flex flex-col justify-between">
          {renderCurrentPage()}
        </div>

        {/* Android Native Gesture Navigation Bar Pill */}
        <div className="w-full py-1.5 bg-[#050505] flex justify-center items-center select-none shrink-0 border-t border-transparent">
          <div className="w-32 h-1 bg-[#444] rounded-full" />
        </div>
      </div>

      {/* 24 Pages Audit & Navigation Drawer Modal */}
      {showPageRegistryDrawer && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-end animate-in fade-in duration-200">
          <div className="w-full max-w-sm h-full bg-[#0B0B0F] border-l border-[#27272A] flex flex-col justify-between p-4 shadow-2xl overflow-y-auto">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-[#27272A]">
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                    <ListTree className="w-4 h-4 text-[#B6FF00]" />
                    <span>24 Pages Registry Audit</span>
                  </h3>
                  <p className="text-[11px] text-[#888888]">100% verified & implemented</p>
                </div>
                <button
                  onClick={() => setShowPageRegistryDrawer(false)}
                  className="w-8 h-8 rounded-lg bg-[#121216] border border-[#27272A] text-[#888888] hover:text-white flex items-center justify-center cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-4 py-4">
                {['Startup', 'Dashboard', 'Expenses', 'Budgets', 'Analytics', 'Settings'].map(
                  (sec) => {
                    const pagesInSec = ALL_PAGES.filter((p) => p.section === sec);
                    return (
                      <div key={sec} className="space-y-1.5">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-[#B6FF00] px-1">
                          {sec} ({pagesInSec.length})
                        </span>
                        <div className="space-y-1">
                          {pagesInSec.map((p) => {
                            const isCurrent = navigation.currentPage === p.name;
                            return (
                              <button
                                key={p.name}
                                onClick={() => {
                                  navigate(p.name);
                                  setShowPageRegistryDrawer(false);
                                }}
                                className={`w-full flex items-center justify-between py-2 px-3 rounded-xl text-xs font-medium text-left transition-all cursor-pointer ${
                                  isCurrent
                                    ? 'bg-[#B6FF00] text-black font-bold shadow-[0_0_10px_rgba(182,255,0,0.3)]'
                                    : 'bg-[#121216] text-[#CCC] hover:bg-[#1A1A22] border border-[#27272A]'
                                }`}
                              >
                                <span className="truncate">{p.label}</span>
                                <CheckCircle2
                                  className={`w-3.5 h-3.5 shrink-0 ${
                                    isCurrent ? 'text-black' : 'text-[#39FF14]'
                                  }`}
                                />
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  }
                )}
              </div>
            </div>

            <div className="pt-4 border-t border-[#27272A] text-center">
              <p className="text-xs text-[#888888] font-tamil">
                Developed by <span className="text-white font-semibold">மூ சதீஷ்</span>
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainRouter />
    </AppProvider>
  );
}
